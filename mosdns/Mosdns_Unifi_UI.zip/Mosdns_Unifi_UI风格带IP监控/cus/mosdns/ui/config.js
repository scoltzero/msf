window.MOSDNS_UI_CONFIG = {
  apiBase: "",

  trafficApiBase: (() => {
    const rawHost = window.location.hostname || "127.0.0.1";
    const host = rawHost.includes(":") ? `[${rawHost}]` : rawHost;
    return `${window.location.protocol}//${host}:9199`;
  })(),

  title: "MosDNS 控制台",
  refreshInterval: 15,
  trafficRefreshInterval: 1,
  requestTimeout: 10000,
  demoOnApiFailure: false
};
