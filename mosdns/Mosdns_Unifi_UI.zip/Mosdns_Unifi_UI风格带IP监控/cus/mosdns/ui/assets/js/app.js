(() => {
  'use strict';

  const CONFIG = Object.assign({
    apiBase: '', trafficApiBase: '', title: 'MosDNS 控制台', refreshInterval: 15, trafficRefreshInterval: 1,
    requestTimeout: 10000, demoOnApiFailure: false
  }, window.MOSDNS_UI_CONFIG || {});
  const API_BASE = String(CONFIG.apiBase || '').replace(/\/$/, '');
  const TRAFFIC_API_BASE = String(CONFIG.trafficApiBase || '').replace(/\/$/, '');
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const page = $('#page-content');
  const storage = { get(k){ try { return window.localStorage.getItem(k); } catch { return null; } }, set(k,v){ try { window.localStorage.setItem(k,String(v)); } catch {} } };
  const state = {
    route: 'overview', charts: [], history: [], lastStats: null, lastStatsAt: null,
    logs: { page: 1, limit: 50, q: '', exact: false, type: '', set: '', code: '', client: '' },
    ruleTag: 'whitelist', upstreamConfig: null, aliases: {},
    refreshTimer: null, trafficTimer: null, mobileMoreOpen: false,
    trafficSort: {key:'ip', dir:'asc'}, trafficHistory: [], trafficChart: null, trafficLatest: null, trafficDetailIP: null, trafficDetailBusy: false
  };

  const icons = {
    overview:'<path d="M4 13h6V3H4v10Zm0 8h6v-6H4v6Zm10 0h6V11h-6v10Zm0-18v6h6V3h-6Z"/>',
    logs:'<path d="M5 4h14v2H5V4Zm0 5h14v2H5V9Zm0 5h9v2H5v-2Zm0 5h7v2H5v-2Z"/>',
    upstream:'<path d="M12 3a5 5 0 0 1 5 5v1h1a3 3 0 1 1 0 6h-1v1a5 5 0 0 1-10 0v-1H6a3 3 0 1 1 0-6h1V8a5 5 0 0 1 5-5Zm-3 6h6V8a3 3 0 1 0-6 0v1Zm0 6v1a3 3 0 1 0 6 0v-1H9Z"/>',
    rules:'<path d="M4 4h7v7H4V4Zm2 2v3h3V6H6Zm7-2h7v7h-7V4Zm2 2v3h3V6h-3ZM4 13h7v7H4v-7Zm2 2v3h3v-3H6Zm7-2h2v2h-2v-2Zm3 0h4v2h-4v-2Zm-3 3h7v2h-7v-2Zm0 3h5v2h-5v-2Z"/>',
    data:'<path d="M12 3c-4.42 0-8 1.34-8 3v12c0 1.66 3.58 3 8 3s8-1.34 8-3V6c0-1.66-3.58-3-8-3Zm0 2c3.48 0 5.65.82 5.98 1-.33.18-2.5 1-5.98 1s-5.65-.82-5.98-1c.33-.18 2.5-1 5.98-1ZM6 8.45C7.47 8.82 9.55 9 12 9s4.53-.18 6-.55V11c0 .35-2.1 1-6 1s-6-.65-6-1V8.45Zm0 5C7.47 13.82 9.55 14 12 14s4.53-.18 6-.55V16c0 .35-2.1 1-6 1s-6-.65-6-1v-2.55Zm6 5.55c-3.9 0-6-.65-6-1v-.55c1.47.37 3.55.55 6 .55s4.53-.18 6-.55V18c0 .35-2.1 1-6 1Z"/>',
    settings:'<path d="M19.43 12.98c.04-.32.07-.65.07-.98s-.03-.66-.08-.98l2.11-1.65-2-3.46-2.49 1a7.54 7.54 0 0 0-1.7-.99L15 3.25h-4l-.35 2.67c-.61.25-1.18.58-1.7.99l-2.49-1-2 3.46 2.11 1.65c-.05.32-.08.65-.08.98s.03.66.08.98l-2.11 1.65 2 3.46 2.49-1c.52.41 1.09.74 1.7.99L11 20.75h4l.35-2.67c.61-.25 1.18-.58 1.7-.99l2.49 1 2-3.46-2.11-1.65ZM13 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8Z"/>',
    features:'<path d="M7 2h2v3h6V2h2v3h2a2 2 0 0 1 2 2v3h-2V7H5v10h5v2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2V2Zm8 10h2v3h3v2h-3v3h-2v-3h-3v-2h3v-3Z"/>',
    system:'<path d="M4 4h16v12H4V4Zm2 2v8h12V6H6Zm3 12h6v2H9v-2Z"/>',
    refresh:'<path d="M17.65 6.35A8 8 0 1 0 20 12h-2a6 6 0 1 1-1.76-4.24L13 11h8V3l-3.35 3.35Z"/>',
    theme:'<path d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.91-.1-1.35A7 7 0 0 1 12 3Z"/>',
    menu:'<path d="M4 6h16v2H4V6Zm0 5h16v2H4v-2Zm0 5h16v2H4v-2Z"/>',
    close:'<path d="m6.4 5 5.6 5.6L17.6 5 19 6.4 13.4 12l5.6 5.6-1.4 1.4-5.6-5.6L6.4 19 5 17.6l5.6-5.6L5 6.4 6.4 5Z"/>',
    chevron:'<path d="m8.6 4.6 7.4 7.4-7.4 7.4L7.2 18l6-6-6-6 1.4-1.4Z"/>',
    search:'<path d="M10 4a6 6 0 1 0 3.87 10.59L19.28 20 20.7 18.6l-5.41-5.41A6 6 0 0 0 10 4Zm0 2a4 4 0 1 1 0 8 4 4 0 0 1 0-8Z"/>',
    plus:'<path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6V5Z"/>',
    edit:'<path d="m14.69 4.86 4.45 4.45L8.45 20H4v-4.45L14.69 4.86Zm0 2.83L6 16.38V18h1.62l8.69-8.69-1.62-1.62ZM17.5 2 22 6.5l-1.45 1.45-4.5-4.5L17.5 2Z"/>',
    trash:'<path d="M8 3h8l1 2h4v2H3V5h4l1-2Zm-2 6h12l-1 12H7L6 9Zm3 2 .5 8h2L11 11H9Zm4 0-.5 8h2l.5-8h-2Z"/>',
    save:'<path d="M4 3h14l2 2v16H4V3Zm2 2v14h12V6.83L17.17 5H16v5H8V5H6Zm4 0v3h4V5h-4Zm-1 8h6v4H9v-4Z"/>',
    info:'<path d="M11 10h2v7h-2v-7Zm0-4h2v2h-2V6Zm1-4a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16Z"/>',
    check:'<path d="m9.2 16.2-4.4-4.4L3.4 13.2 9.2 19 21 7.2 19.6 5.8 9.2 16.2Z"/>',
    warning:'<path d="M12 3 2 21h20L12 3Zm0 4.1L18.6 19H5.4L12 7.1ZM11 10h2v5h-2v-5Zm0 6h2v2h-2v-2Z"/>',
    download:'<path d="M11 3h2v9l3-3 1.4 1.4L12 15.8l-5.4-5.4L8 9l3 3V3ZM4 18h16v3H4v-3Z"/>',
    more:'<path d="M5 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"/>'
  };
  const icon = (name, cls='') => `<svg class="${cls}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">${icons[name] || icons.info}</svg>`;
  const esc = (v='') => String(v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const num = v => Number.isFinite(+v) ? (+v).toLocaleString('zh-CN') : '—';
  const pct = v => Number.isFinite(+v) ? `${(+v).toFixed(2)}%` : '—';
  const compactNum = v => {
    const n=+v;
    if(!Number.isFinite(n))return '—';
    if(Math.abs(n)<10000)return n.toLocaleString('zh-CN');
    return new Intl.NumberFormat('zh-CN',{notation:'compact',compactDisplay:'short',maximumFractionDigits:1}).format(n);
  };
  const compactPct = v => {
    const n=+v;
    if(!Number.isFinite(n))return '—';
    return `${Number.isInteger(n)?n.toFixed(0):n.toFixed(1)}%`;
  };
  const ms = v => Number.isFinite(+v) ? `${(+v).toFixed(2)} ms` : '—';
  const fmtBytes = v => { const n=+v; if(!Number.isFinite(n))return '—'; const u=['B','KB','MB','GB','TB']; let i=0,x=n; while(x>=1024&&i<u.length-1){x/=1024;i++;} return `${x.toFixed(i?2:0)} ${u[i]}`; };
  const fmtDate = v => { if(!v)return '—'; const d=new Date(v); return Number.isNaN(d.getTime())?String(v):d.toLocaleString('zh-CN',{hour12:false}); };
  const timeAgo = v => { if(!v)return '—'; const d=new Date(v).getTime(); if(!Number.isFinite(d))return '—'; const s=Math.max(0,Math.floor((Date.now()-d)/1000)); if(s<60)return `${s}秒前`; if(s<3600)return `${Math.floor(s/60)}分钟前`; if(s<86400)return `${Math.floor(s/3600)}小时前`; return `${Math.floor(s/86400)}天前`; };
  const duration = seconds => { let s=Math.max(0,Math.floor(+seconds||0)); const d=Math.floor(s/86400);s%=86400;const h=Math.floor(s/3600);s%=3600;const m=Math.floor(s/60);return `${d?d+'天 ':''}${h? h+'小时 ':''}${m}分钟`; };
  const durationCompact = seconds => { let s=Math.max(0,Math.floor(+seconds||0)); const d=Math.floor(s/86400);s%=86400;const h=Math.floor(s/3600);s%=3600;const m=Math.floor(s/60); if(d)return h?`${d}天 ${h}小时`:`${d}天`; if(h)return m?`${h}小时 ${m}分钟`:`${h}小时`; return `${m}分钟`; };

  const routeDefs = [
    {section:'监控', id:'overview', label:'运行概览', icon:'overview', subtitle:'实时查看 DNS 运行状态与关键指标'},
    {section:'监控', id:'logs', label:'查询日志', icon:'logs', subtitle:'搜索、筛选并分析 DNS 请求记录'},
    {section:'配置', id:'upstreams', label:'上游 DNS', icon:'upstream', subtitle:'管理上游服务器并查看请求、采纳与错误统计'},
    {section:'配置', id:'rules', label:'规则管理', icon:'rules', subtitle:'统一维护名单、广告拦截与在线分流规则'},
    {section:'配置', id:'data', label:'数据管理', icon:'data', subtitle:'缓存、域名统计与分流缓存刷新'},
    {section:'系统', id:'settings', label:'基础设置', icon:'settings', subtitle:'审计、覆盖配置、自动刷新与配置管理'},
    {section:'系统', id:'features', label:'功能开关', icon:'features', subtitle:'调整核心运行模式与解析功能'},
    {section:'系统', id:'system', label:'系统信息', icon:'system', subtitle:'运行状态、版本更新与服务控制'}
  ];

  const api = {
    url: p => `${API_BASE}${p}`,
    async request(path, options={}) {
      const ctrl = new AbortController(); const timer = setTimeout(()=>ctrl.abort(), CONFIG.requestTimeout);
      try {
        const headers = Object.assign({}, options.headers || {});
        const res = await fetch(this.url(path), Object.assign({}, options, {headers, signal: options.signal || ctrl.signal}));
        const ct = res.headers.get('content-type') || '';
        let body; if (ct.includes('application/json')) body = await res.json(); else body = await res.text();
        if (!res.ok) throw new Error((body && body.error) || (typeof body==='string' && body) || `HTTP ${res.status}`);
        return body;
      } finally { clearTimeout(timer); }
    },
    json(path, method='GET', body) { return this.request(path,{method,headers:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)}); },
    metrics() { return this.request('/metrics'); },
    status() { return this.request('/api/v1/audit/status'); },
    capacity() { return this.request('/api/v1/audit/capacity'); },
    stats() { return this.request('/api/v2/audit/stats'); },
    rank(type,limit=10) { return this.request(`/api/v2/audit/rank/${type}?limit=${limit}`); },
    logs(params={}) { const qs=new URLSearchParams({page:1,limit:50,...params}); [...qs].forEach(([k,v])=>{if(v===''||v==null)qs.delete(k)}); return this.request(`/api/v2/audit/logs?${qs}`); }
  };


  const trafficApi = {
    url: p => `${TRAFFIC_API_BASE}${p}`,
    async request(path) {
      const ctrl = new AbortController();
      const timer = setTimeout(()=>ctrl.abort(), CONFIG.requestTimeout);
      try {
        const res = await fetch(this.url(path), {cache:'no-store', signal:ctrl.signal});
        const body = await res.json().catch(()=>({}));
        if(!res.ok) throw new Error(body.error || `HTTP ${res.status}`);
        return body;
      } finally { clearTimeout(timer); }
    },
    snapshot() { return this.request('/api/traffic/snapshot'); },
    client(ip) { return this.request(`/api/traffic/client?ip=${encodeURIComponent(ip)}`); },
    status() { return this.request('/api/traffic/status'); }
  };

  function toast(message, type='success', detail='') {
    const el=document.createElement('div'); el.className=`toast ${type}`;
    el.innerHTML=`<span>${icon(type==='error'?'warning':type==='success'?'check':'info')}</span><div><strong>${esc(message)}</strong>${detail?`<div class="toast-info">${esc(detail)}</div>`:''}</div>`;
    $('#toast-stack').appendChild(el); setTimeout(()=>el.remove(),4200);
  }
  function setApiStatus(ok, text) {
    const box=$('#sidebar-status'), dot=$('.status-dot',box), strong=$('strong',box);
    dot.className=`status-dot ${ok?'online':'offline'}`; strong.textContent=ok?'MosDNS 运行正常':'MosDNS 连接异常';
    $('#api-endpoint-label').textContent=text || (API_BASE || location.host);
  }
  function setUpdated() { $('#last-update').textContent=`更新于 ${new Date().toLocaleTimeString('zh-CN',{hour12:false})}`; }
  function destroyCharts(){ state.charts.forEach(c=>{try{c.destroy()}catch{}}); state.charts=[]; state.trafficChart=null; }
  function chart(el, cfg){ if(!window.Chart||!el)return null; const c=new Chart(el,cfg); state.charts.push(c); return c; }
  function chartColors(){ const css=getComputedStyle(document.documentElement); return {primary:css.getPropertyValue('--primary').trim(),green:css.getPropertyValue('--green').trim(),orange:css.getPropertyValue('--orange').trim(),pink:css.getPropertyValue('--pink').trim(),cyan:css.getPropertyValue('--cyan').trim(),muted:css.getPropertyValue('--muted').trim(),border:css.getPropertyValue('--border').trim(),text:css.getPropertyValue('--text-2').trim(),surface:css.getPropertyValue('--surface-2').trim()}; }

  function parseProm(text) {
    const out=[];
    String(text||'').split('\n').forEach(line=>{
      line=line.trim(); if(!line||line.startsWith('#'))return;
      const m=line.match(/^([a-zA-Z_:][\w:]*)({([^}]*)})?\s+([^\s]+)$/); if(!m)return;
      const labels={}; if(m[3]) { const re=/(\w+)="((?:\\.|[^"])*)"/g; let x; while((x=re.exec(m[3]))) labels[x[1]]=x[2].replace(/\\"/g,'"').replace(/\\\\/g,'\\'); }
      out.push({name:m[1],labels,value:Number(m[4])});
    }); return out;
  }
  function metricFind(metrics,name,labels={}){ const m=metrics.find(x=>x.name===name&&Object.entries(labels).every(([k,v])=>x.labels[k]===v)); return m?m.value:0; }
  function parseSystem(metrics){ const start=metricFind(metrics,'process_start_time_seconds'); const info=metrics.find(x=>x.name==='go_info'); return {
    start, uptime:start?Date.now()/1000-start:0, cpu:metricFind(metrics,'process_cpu_seconds_total'), rss:metricFind(metrics,'process_resident_memory_bytes'), heapIdle:metricFind(metrics,'go_memstats_heap_idle_bytes'),
    go:info?.labels?.version||'—', threads:metricFind(metrics,'go_threads'), goroutines:metricFind(metrics,'go_goroutines'), fds:metricFind(metrics,'process_open_fds')
  };}
  function parseCaches(metrics){ const tags=['cache_all','cache_all_noleak','cache_cn','cache_google','cache_google_node','cache_node']; return tags.map(tag=>{const q=metricFind(metrics,'mosdns_cache_query_total',{tag}),h=metricFind(metrics,'mosdns_cache_hit_total',{tag}),l=metricFind(metrics,'mosdns_cache_lazy_hit_total',{tag}),size=metricFind(metrics,'mosdns_cache_size_current',{tag});return{tag,q,h,l,size,hit:q?h/q*100:0,lazy:q?l/q*100:0};}); }
  function upstreamMetrics(metrics,group,tag){ const labels={metrics_tag:group,tag}; const q=metricFind(metrics,'mosdns_aliapi_query_total',labels),err=metricFind(metrics,'mosdns_aliapi_error_total',labels),win=metricFind(metrics,'mosdns_aliapi_upstream_winner_total',labels),sum=metricFind(metrics,'mosdns_aliapi_response_latency_millisecond_sum',labels),count=metricFind(metrics,'mosdns_aliapi_response_latency_millisecond_count',labels); return {q,err,win,latency:count?sum/count:0,success:q?Math.max(0,(q-err)/q*100):100,adoption:q?win/q*100:0}; }

  function navHtml() {
    let sec=''; return routeDefs.map(r=>{let h='';if(r.section!==sec){sec=r.section;h=`<div class="nav-section-label">${esc(sec)}</div>`;}return h+`<button class="nav-item" data-route="${r.id}"><span class="nav-icon">${icon(r.icon)}</span><span class="nav-label">${r.label}</span></button>`;}).join('');
  }
  function fitRuleLayoutHeight(){
    const layout=$('.rule-layout');
    if(!layout)return;
    if(window.innerWidth<=900){
      layout.style.removeProperty('height');
      layout.style.removeProperty('min-height');
      return;
    }
    const status=$('#sidebar-status');
    const targetBottom=status&&status.offsetParent!==null?status.getBoundingClientRect().bottom:window.innerHeight-18;
    const top=layout.getBoundingClientRect().top;
    const available=Math.max(500,Math.floor(targetBottom-top));
    layout.style.height=`${available}px`;
    layout.style.minHeight='0';
  }

  function initShell(){
    document.title=CONFIG.title; $('#side-nav').innerHTML=navHtml();
    const mobile=[['overview','overview','概览'],['logs','logs','日志'],['upstreams','upstream','上游'],['rules','rules','规则'],['settings','more','更多']];
    $('#mobile-nav').innerHTML=mobile.map(([r,i,l])=>`<button data-route="${r}">${icon(i)}<span>${l}</span></button>`).join('');
    const sidebarCollapse=$('#sidebar-collapse');
    sidebarCollapse.innerHTML=icon('chevron'); $('#mobile-menu').innerHTML=icon('menu'); $('#theme-toggle').innerHTML=icon('theme'); $('#refresh-button').innerHTML=icon('refresh'); $('#drawer-close').innerHTML=icon('close'); $$('#modal .icon-button').forEach(x=>x.innerHTML=icon('close'));
    const syncSidebarCollapse=()=>{const collapsed=document.body.classList.contains('sidebar-collapsed');const label=collapsed?'展开侧栏':'折叠侧栏';sidebarCollapse.setAttribute('aria-label',label);sidebarCollapse.setAttribute('title',label);sidebarCollapse.setAttribute('aria-expanded',String(!collapsed));};
    sidebarCollapse.onclick=()=>{document.body.classList.toggle('sidebar-collapsed');storage.set('mosdnsSidebarCollapsed',document.body.classList.contains('sidebar-collapsed'));syncSidebarCollapse()};
    if(storage.get('mosdnsSidebarCollapsed')==='true')document.body.classList.add('sidebar-collapsed');
    syncSidebarCollapse();
    $('#mobile-menu').onclick=()=>document.body.classList.toggle('mobile-sidebar-open');
    document.addEventListener('click',e=>{const b=e.target.closest('[data-route]');if(!b)return;navigate(b.dataset.route);document.body.classList.remove('mobile-sidebar-open')});
    $('#refresh-button').onclick=()=>renderRoute(true);
    $('#theme-toggle').onclick=()=>{const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;storage.set('mosdnsTheme',t);renderRoute(true)};
    document.documentElement.dataset.theme=storage.get('mosdnsTheme')||'light';
    $('#drawer-close').onclick=closeDrawer; $('#drawer-backdrop').onclick=closeDrawer;
    window.addEventListener('hashchange',()=>navigate((location.hash.replace(/^#\/?/,'')||'overview'),false));
    window.addEventListener('resize',()=>{if(state.route==='rules')requestAnimationFrame(fitRuleLayoutHeight)});
  }
  function navigate(id,write=true){ if(!routeDefs.some(x=>x.id===id))id='overview';state.route=id;if(write&&location.hash!==`#/${id}`)history.pushState(null,'',`#/${id}`);renderRoute(); }
  function updateNav(){ const r=routeDefs.find(x=>x.id===state.route); $('#page-title').textContent=r.label;$('#page-subtitle').textContent=r.subtitle;$$('[data-route]').forEach(x=>x.classList.toggle('active',x.dataset.route===state.route)); }
  async function renderRoute(force=false){
    destroyCharts(); updateNav(); clearInterval(state.refreshTimer); clearInterval(state.trafficTimer); state.trafficTimer=null; page.innerHTML=loadingPage();
    try {
      const fn={overview:renderOverview,logs:renderLogs,upstreams:renderUpstreams,rules:renderRules,data:renderData,settings:renderSettings,features:renderFeatures,system:renderSystem}[state.route];
      await fn(force); setApiStatus(true); setUpdated();
    } catch(e){ console.error(e); setApiStatus(false,e.message); page.innerHTML=`<div class="error-panel"><strong>无法加载当前页面</strong><p>${esc(e.message)}</p><button class="button" id="retry-page">${icon('refresh')}重新加载</button></div>`; $('#retry-page').onclick=()=>renderRoute(true); }
    if(state.route==='logs'){state.refreshTimer=setInterval(()=>{if(document.visibilityState==='visible')renderRoute(true)},Math.max(5,+CONFIG.refreshInterval||15)*1000)}
  }
  const loadingPage=()=>`<div class="grid grid-4 metrics-grid-mobile">${[1,2,3,4].map(()=>`<div class="metric-card skeleton" style="height:112px"></div>`).join('')}</div><div class="card skeleton" style="height:340px;margin-top:16px"></div>`;

  function metricCard(label,value,note='',iconName='overview',hero=false,noteClass=''){return `<div class="metric-card ${hero?'hero-card':''}"><div class="metric-top"><span>${esc(label)}</span><span class="metric-icon">${icon(iconName)}</span></div><div class="metric-value">${value}</div><div class="metric-note ${noteClass}">${note||'&nbsp;'}</div></div>`;}
  function card(title,body,{iconName='overview',subtitle='',actions='',className=''}={}){return `<section class="card ${className}"><div class="card-header"><div class="card-title"><span class="icon">${icon(iconName)}</span><div><h2>${esc(title)}</h2>${subtitle?`<p>${esc(subtitle)}</p>`:''}</div></div><div class="card-actions">${actions}</div></div><div class="card-body">${body}</div></section>`;}
  const empty=(text='暂无数据')=>`<div class="empty-state"><div><div class="empty-icon">${icon('info')}</div><strong>${esc(text)}</strong></div></div>`;
  function rankRows(items,formatter=(x)=>x.key){
    if(!items?.length)return empty();
    const list=items.slice(0,10), max=Math.max(1,...list.map(x=>+x.count||0));
    return `<div class="rank-list">${list.map((x,i)=>{const width=Math.max(4,Math.min(100,(+x.count||0)/max*100));return `<div class="rank-row" style="--rank:${width.toFixed(2)}%"><span class="rank-meter"></span><span class="rank-index">${i+1}</span><span class="rank-name" title="${esc(formatter(x))}">${esc(formatter(x))}</span><span class="rank-value">${num(x.count)}</span></div>`}).join('')}</div>`;
  }


  const fmtRate = v => `${fmtBytes(v)}/s`;
  const idleText = seconds => {
    const n=Math.max(0,+seconds||0);
    if(n<1)return '刚刚';
    if(n<60)return `${Math.floor(n)}秒`;
    if(n<3600)return `${Math.floor(n/60)}分钟`;
    return `${Math.floor(n/3600)}小时`;
  };
  function trafficProtocolNames(items){
    if(!items?.length)return [];
    return items.map(x=>String(Array.isArray(x)?x[0]:x?.name||'')).filter(Boolean);
  }
  function trafficBadges(items){
    const names=trafficProtocolNames(items);
    if(!names.length)return '<span class="traffic-muted">—</span>';
    return names.slice(0,4).map(x=>`<span class="traffic-proto">${esc(x)}</span>`).join('');
  }
  function trafficPeers(items){
    if(!items?.length)return '—';
    return items.slice(0,2).map(x=>{
      const name=Array.isArray(x)?x[0]:x.name;
      const value=Array.isArray(x)?x[1]:x.value;
      return `${esc(name)} <small>${fmtBytes(value)}</small>`;
    }).join('<br>');
  }
  function trafficPeerSortValue(items){
    if(!items?.length)return '';
    const x=items[0];
    return String(Array.isArray(x)?x[0]:x?.name||'');
  }
  function compareTrafficIP(a,b){
    const av4=/^(\d{1,3})(?:\.(\d{1,3})){3}$/.test(a);
    const bv4=/^(\d{1,3})(?:\.(\d{1,3})){3}$/.test(b);
    if(av4&&bv4){
      const aa=a.split('.').map(Number),bb=b.split('.').map(Number);
      for(let i=0;i<4;i++){if(aa[i]!==bb[i])return aa[i]-bb[i]}
      return 0;
    }
    if(av4!==bv4)return av4?-1:1;
    return String(a).localeCompare(String(b),'zh-CN',{numeric:true,sensitivity:'base'});
  }
  function trafficSortValue(d,key){
    switch(key){
      case 'rx_rate': return +d.rx_rate||0;
      case 'tx_rate': return +d.tx_rate||0;
      case 'connections': return +d.connections||0;
      case 'protocols': return trafficProtocolNames(d.protocols).join(' ');
      case 'peers': return trafficPeerSortValue(d.peers);
      case 'last_seen': return +d.last_seen||0;
      default: return String(d.ip||'');
    }
  }
  function sortedTrafficDevices(devices){
    const list=[...(devices||[])],{key,dir}=state.trafficSort,sign=dir==='asc'?1:-1;
    list.sort((a,b)=>{
      let cmp;
      if(key==='ip')cmp=compareTrafficIP(String(a.ip||''),String(b.ip||''));
      else{
        const av=trafficSortValue(a,key),bv=trafficSortValue(b,key);
        cmp=typeof av==='number'&&typeof bv==='number'?av-bv:String(av).localeCompare(String(bv),'zh-CN',{numeric:true,sensitivity:'base'});
      }
      if(cmp===0)cmp=compareTrafficIP(String(a.ip||''),String(b.ip||''));
      return cmp*sign;
    });
    return list;
  }
  function trafficHeader(label,key){
    const active=state.trafficSort.key===key;
    const arrow=active?(state.trafficSort.dir==='asc'?'↑':'↓'):'↕';
    return `<th class="traffic-sortable ${active?'is-sorted':''}" data-traffic-sort="${key}" aria-sort="${active?(state.trafficSort.dir==='asc'?'ascending':'descending'):'none'}"><button type="button"><span>${label}</span><i>${arrow}</i></button></th>`;
  }
  function trafficRows(data){
    const devices=Array.isArray(data?.devices)?data.devices:[];
    const maxRx=Math.max(1,...devices.map(x=>+x.rx_rate||0));
    const maxTx=Math.max(1,...devices.map(x=>+x.tx_rate||0));
    const sorted=sortedTrafficDevices(devices);
    return sorted.length?sorted.map(d=>{
      const rx=Math.max(0,+d.rx_rate||0), tx=Math.max(0,+d.tx_rate||0);
      const rxWidth=Math.max(rx?3:0,Math.min(100,rx/maxRx*100));
      const txWidth=Math.max(tx?3:0,Math.min(100,tx/maxTx*100));
      return `<tr data-traffic-ip="${esc(d.ip)}">
        <td class="traffic-ip"><button type="button" class="traffic-ip-button" data-traffic-detail="${esc(d.ip)}" title="查看 ${esc(d.ip)} 的详细统计"><strong>${esc(d.ip)}</strong><span>查看详情</span></button></td>
        <td><span class="traffic-rate-value">${fmtRate(rx)}</span><span class="traffic-rate-bar download"><i style="width:${rxWidth.toFixed(1)}%"></i></span></td>
        <td><span class="traffic-rate-value">${fmtRate(tx)}</span><span class="traffic-rate-bar upload"><i style="width:${txWidth.toFixed(1)}%"></i></span></td>
        <td class="traffic-connections">${num(d.connections||0)}</td>
        <td><div class="traffic-protocols">${trafficBadges(d.protocols)}</div></td>
        <td class="traffic-peers">${trafficPeers(d.peers)}</td>
        <td class="traffic-idle">${idleText(d.last_seen)}</td>
      </tr>`;
    }).join(''):`<tr><td colspan="7" class="table-empty">暂时没有检测到客户端流量</td></tr>`;
  }
  function trafficDetailPairs(items, emptyText='暂无统计'){
    if(!Array.isArray(items)||!items.length)return `<div class="traffic-detail-empty">${esc(emptyText)}</div>`;
    return items.map(x=>`<div class="traffic-detail-pair"><span title="${esc(x?.[0]||'')}">${esc(x?.[0]||'—')}</span><strong>${fmtBytes(x?.[1]||0)}</strong></div>`).join('');
  }
  function trafficDetailFlows(items){
    if(!Array.isArray(items)||!items.length)return `<div class="traffic-detail-empty">暂无活跃连接</div>`;
    return `<div class="table-wrap traffic-detail-flow-wrap"><table class="table-compact traffic-detail-flow-table"><thead><tr><th>协议</th><th>主要对端</th><th>下载</th><th>上传</th><th>空闲</th></tr></thead><tbody>${items.map(f=>`<tr><td><span class="traffic-proto">${esc(f.app||f.proto||'—')}</span></td><td title="${esc(f.dst||'')}">${esc(f.dst||'—')}</td><td>${fmtBytes(f.rx_bytes||0)}</td><td>${fmtBytes(f.tx_bytes||0)}</td><td>${idleText(f.idle||0)}</td></tr>`).join('')}</tbody></table></div>`;
  }
  function trafficDetailHtml(d){
    const first=d.first_seen?new Date(Number(d.first_seen)*1000).toLocaleString('zh-CN',{hour12:false}):'—';
    const online=!!d.online;
    return `<div class="traffic-detail">
      <div class="traffic-detail-hero">
        <div><span class="traffic-detail-kicker">设备地址</span><strong title="${esc(d.ip||'')}">${esc(d.ip||'—')}</strong><small>${esc(d.address_family||'—')} · ${online?'在线':'空闲'}</small></div>
        <span class="traffic-detail-status ${online?'online':'idle'}"><i></i>${online?'在线':'空闲'}</span>
      </div>
      <div class="traffic-detail-metrics">
        <div><span>当前下载</span><strong>${fmtRate(d.rx_rate||0)}</strong></div>
        <div><span>当前上传</span><strong>${fmtRate(d.tx_rate||0)}</strong></div>
        <div><span>本次运行下载</span><strong>${fmtBytes(d.rx_total||0)}</strong></div>
        <div><span>本次运行上传</span><strong>${fmtBytes(d.tx_total||0)}</strong></div>
        <div><span>本次运行总流量</span><strong>${fmtBytes(d.total||0)}</strong></div>
        <div><span>活跃连接</span><strong>${num(d.connections||0)}</strong></div>
      </div>
      <div class="traffic-detail-section"><h3>设备信息</h3><div class="kv-list">
        <div class="kv-row"><span class="kv-key">首次出现</span><span class="kv-value">${esc(first)}</span></div>
        <div class="kv-row"><span class="kv-key">最近活动</span><span class="kv-value">${idleText(d.last_seen||0)}</span></div>
        <div class="kv-row"><span class="kv-key">持续观察</span><span class="kv-value">${trafficRuntime(d.observed_seconds||0)}</span></div>
        <div class="kv-row"><span class="kv-key">累计数据包</span><span class="kv-value">${num(d.packets||0)}</span></div>
        <div class="kv-row"><span class="kv-key">采集模式</span><span class="kv-value">被动旁路 AF_PACKET</span></div>
      </div></div>
      <div class="traffic-detail-section"><h3>协议累计流量</h3><div class="traffic-detail-pairs">${trafficDetailPairs(d.protocols,'暂无协议统计')}</div></div>
      <div class="traffic-detail-section"><h3>主要对端</h3><div class="traffic-detail-pairs peers">${trafficDetailPairs(d.peers,'暂无主要对端')}</div></div>
      <div class="traffic-detail-section"><h3>活跃连接</h3>${trafficDetailFlows(d.flows)}</div>
      <p class="traffic-detail-note">累计值从本次 traffic-agent 启动后开始计算，服务重启后会重新累计。</p>
    </div>`;
  }
  async function refreshTrafficDetail(force=false){
    const ip=state.trafficDetailIP;
    if(!ip||state.trafficDetailBusy)return;
    if(!force&&!$('#drawer').classList.contains('open'))return;
    state.trafficDetailBusy=true;
    try{
      const d=await trafficApi.client(ip);
      if(state.trafficDetailIP!==ip)return;
      $('#drawer-title').textContent='设备流量详情';
      $('#drawer-subtitle').textContent=ip;
      $('#drawer-content').innerHTML=trafficDetailHtml(d);
    }catch(e){
      if(state.trafficDetailIP===ip)$('#drawer-content').innerHTML=`<div class="traffic-detail-empty error">读取详情失败：${esc(e.message||e)}</div>`;
    }finally{state.trafficDetailBusy=false}
  }
  function openTrafficDetail(ip){
    state.trafficDetailIP=ip;
    openDrawer('设备流量详情',ip,`<div class="traffic-detail-loading">${loadingPage()}</div>`);
    refreshTrafficDetail(true);
  }
  function bindTrafficDetail(){
    $$('.traffic-ip-button').forEach(btn=>btn.onclick=()=>openTrafficDetail(btn.dataset.trafficDetail));
  }

  function trafficRuntime(seconds){
    let s=Math.max(0,Math.floor(+seconds||0));
    const d=Math.floor(s/86400);s%=86400;const h=Math.floor(s/3600);s%=3600;const m=Math.floor(s/60);const sec=s%60;
    if(d)return `${d}天 ${h}小时`;
    if(h)return `${h}小时 ${m}分`;
    if(m)return `${m}分 ${sec}秒`;
    return `${sec}秒`;
  }
  function trafficSummaryValues(data){
    const devices=Array.isArray(data?.devices)?data.devices:[];
    return {
      rx:fmtRate(data?.rx_rate||0),
      tx:fmtRate(data?.tx_rate||0),
      devices:num(devices.length),
      connections:num(devices.reduce((n,x)=>n+(+x.connections||0),0)),
      uptime:trafficRuntime(data?.uptime||0)
    };
  }
  function trafficCaptureError(data){
    if(data?.error)return data.error;
    const errs=data?.capture_errors&&typeof data.capture_errors==='object'?Object.entries(data.capture_errors):[];
    if(errs.length)return errs.map(([name,msg])=>`${name}: ${msg}`).join('；');
    if(data?.ok===false)return '采集器尚未成功绑定网卡，程序会每 3 秒自动重试。';
    return '';
  }
  function trafficPanelBody(data){
    if(!data || data.error || data.ok===false){
      const detail=trafficCaptureError(data)||'请确认 mosdns-traffic-agent 已启动，并检查 trafficApiBase 配置。';
      return `<div class="traffic-offline"><span>${icon('warning')}</span><div><strong>流量采集暂未就绪</strong><p>${esc(detail)}</p><p>服务会自动重试；也可检查 /etc/monitor/config/config.json 中的接口名称。</p></div></div>`;
    }
    const s=trafficSummaryValues(data);
    return `<div class="traffic-summary">
      <div><span>下载总速率</span><strong id="traffic-summary-rx">${s.rx}</strong></div>
      <div><span>上传总速率</span><strong id="traffic-summary-tx">${s.tx}</strong></div>
      <div><span>设备数量</span><strong id="traffic-summary-devices">${s.devices}</strong></div>
      <div><span>连接数量</span><strong id="traffic-summary-connections">${s.connections}</strong></div>
      <div><span>运行时间</span><strong id="traffic-summary-uptime">${s.uptime}</strong></div>
    </div>
    <div class="traffic-chart-panel">
      <div class="traffic-chart-header"><strong>速率曲线</strong><span><i class="traffic-legend-dot download"></i>下载 <i class="traffic-legend-dot upload"></i>上传</span></div>
      <div class="traffic-chart-wrap"><canvas id="traffic-speed-chart"></canvas></div>
    </div>
    <div class="table-wrap traffic-table-wrap"><table class="traffic-device-table">
      <thead><tr>${trafficHeader('IP','ip')}${trafficHeader('下载','rx_rate')}${trafficHeader('上传','tx_rate')}${trafficHeader('连接','connections')}${trafficHeader('协议','protocols')}${trafficHeader('主要对端','peers')}${trafficHeader('空闲','last_seen')}</tr></thead>
      <tbody id="traffic-device-tbody">${trafficRows(data)}</tbody>
    </table></div>`;
  }
  function appendTrafficHistory(data){
    if(!data||data.error)return;
    const stamp=new Date();
    state.trafficHistory.push({label:stamp.toLocaleTimeString('zh-CN',{hour12:false}),rx:+data.rx_rate||0,tx:+data.tx_rate||0});
    if(state.trafficHistory.length>60)state.trafficHistory.shift();
  }
  function ensureTrafficChart(){
    const el=$('#traffic-speed-chart');
    if(!el||state.trafficChart)return;
    const c=chartColors();
    state.trafficChart=chart(el,{type:'line',data:{labels:[],datasets:[
      {label:'下载',data:[],borderColor:c.primary,backgroundColor:'transparent',borderWidth:2,tension:.26,pointRadius:0,pointHoverRadius:3},
      {label:'上传',data:[],borderColor:c.green,backgroundColor:'transparent',borderWidth:2,tension:.26,pointRadius:0,pointHoverRadius:3}
    ]},options:{responsive:true,maintainAspectRatio:false,animation:false,interaction:{mode:'index',intersect:false},plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>`${ctx.dataset.label}：${fmtRate(ctx.parsed.y)}`}}},scales:{x:{display:false,grid:{display:false}},y:{beginAtZero:true,ticks:{color:c.muted,maxTicksLimit:4,callback:v=>fmtRate(v)},grid:{color:c.border}}}}});
  }
  function updateTrafficChart(data){
    appendTrafficHistory(data);ensureTrafficChart();
    const chartObj=state.trafficChart;if(!chartObj)return;
    chartObj.data.labels=state.trafficHistory.map(x=>x.label);
    chartObj.data.datasets[0].data=state.trafficHistory.map(x=>x.rx);
    chartObj.data.datasets[1].data=state.trafficHistory.map(x=>x.tx);
    chartObj.update('none');
  }
  function updateTrafficSortIndicators(){
    $$('.traffic-sortable').forEach(th=>{
      const active=th.dataset.trafficSort===state.trafficSort.key;
      th.classList.toggle('is-sorted',active);
      th.setAttribute('aria-sort',active?(state.trafficSort.dir==='asc'?'ascending':'descending'):'none');
      const i=$('i',th);if(i)i.textContent=active?(state.trafficSort.dir==='asc'?'↑':'↓'):'↕';
    });
  }
  function bindTrafficSort(){
    $$('.traffic-sortable button').forEach(btn=>btn.onclick=()=>{
      const key=btn.closest('th').dataset.trafficSort;
      if(state.trafficSort.key===key)state.trafficSort.dir=state.trafficSort.dir==='asc'?'desc':'asc';
      else{state.trafficSort.key=key;state.trafficSort.dir=['ip','protocols','peers'].includes(key)?'asc':'desc'}
      const wrap=$('.traffic-table-wrap'),top=wrap?.scrollTop||0,left=wrap?.scrollLeft||0;
      const tbody=$('#traffic-device-tbody');if(tbody&&state.trafficLatest)tbody.innerHTML=trafficRows(state.trafficLatest);
      bindTrafficDetail();
      updateTrafficSortIndicators();
      if(wrap){wrap.scrollTop=top;wrap.scrollLeft=left}
    });
  }
  function updateTrafficSummary(data){
    const s=trafficSummaryValues(data),items={
      '#traffic-summary-rx':s.rx,'#traffic-summary-tx':s.tx,'#traffic-summary-devices':s.devices,
      '#traffic-summary-connections':s.connections,'#traffic-summary-uptime':s.uptime
    };
    Object.entries(items).forEach(([sel,val])=>{const el=$(sel);if(el)el.textContent=val});
  }
  function updateTrafficPanel(data){
    state.trafficLatest=data;
    const body=$('#traffic-panel-body');
    if(body){
      const online=!!data&&!data.error&&data.ok!==false;
      const shellReady=!!$('#traffic-device-tbody',body);
      if(!online||!shellReady){
        if(state.trafficChart){
          try{state.trafficChart.destroy()}catch{}
          state.charts=state.charts.filter(x=>x!==state.trafficChart);
          state.trafficChart=null;
        }
        body.innerHTML=trafficPanelBody(data);
        if(online){bindTrafficSort();bindTrafficDetail();updateTrafficChart(data)}
      }else{
        updateTrafficSummary(data);
        const wrap=$('.traffic-table-wrap',body),top=wrap?.scrollTop||0,left=wrap?.scrollLeft||0;
        const tbody=$('#traffic-device-tbody',body);if(tbody)tbody.innerHTML=trafficRows(data);
        bindTrafficDetail();
        updateTrafficSortIndicators();updateTrafficChart(data);
        if(wrap){wrap.scrollTop=top;wrap.scrollLeft=left}
      }
    }
    const pill=$('#traffic-live-pill');
    if(pill){
      const ok=!!data?.ok && !data?.error;
      pill.classList.toggle('offline',!ok);
      pill.innerHTML=`<span></span>${ok?'实时':'离线'}`;
      pill.title=ok?`采集模式：${data.capture_mode||'eBPF/TC'}；接口：${(data.interfaces||[]).join(', ')||'—'}`:(trafficCaptureError(data)||'流量监控服务未连接');
    }
  }
  function startTrafficPolling(){
    clearInterval(state.trafficTimer);
    const interval=Math.max(1,+CONFIG.trafficRefreshInterval||1)*1000;
    state.trafficTimer=setInterval(async()=>{
      if(state.route!=='overview'||document.visibilityState!=='visible')return;
      try{updateTrafficPanel(await trafficApi.snapshot());if(state.trafficDetailIP)refreshTrafficDetail()}
      catch(e){updateTrafficPanel({error:e.message,ok:false,devices:[]})}
    },interval);
  }

  async function renderOverview(){
    const [stats,domains,clients,slowest,sets,logs,metricsRaw,status,coreModeRaw,cacheSwitchRaw,traffic] = await Promise.all([
      api.stats(),api.rank('domain',10),api.rank('client',10),api.rank('slowest',8),api.rank('domain_set',16),api.logs({limit:200}),api.metrics(),api.status(),
      safe(()=>api.request('/plugins/switch3/show'),''),safe(()=>api.request('/plugins/switch13/show'),''),
      safe(()=>trafficApi.snapshot(),{ok:false,error:'流量监控服务未连接',devices:[],rx_rate:0,tx_rate:0})
    ]);
    const metrics=parseProm(metricsRaw), sys=parseSystem(metrics), caches=parseCaches(metrics); const sample=logs.logs||[]; const ok=sample.filter(x=>x.response_code==='NOERROR').length; const success=sample.length?ok/sample.length*100:100;
    const coreMode=String(coreModeRaw||'').trim().toUpperCase(), cacheSwitch=String(cacheSwitchRaw||'').trim().toUpperCase();
    const coreCaches=caches.filter(x=>x.tag==='cache_all'||x.tag==='cache_all_noleak');
    let cache=coreMode==='B'?coreCaches.find(x=>x.tag==='cache_all_noleak'):coreMode==='A'?coreCaches.find(x=>x.tag==='cache_all'):null;
    if(!cache)cache=coreCaches.slice().sort((a,b)=>(b.q||0)-(a.q||0))[0]||caches[0]||{hit:0,q:0,h:0,l:0,size:0,tag:''};
    const cacheModeLabel=coreMode==='B'?'安全模式':coreMode==='A'?'兼容模式':cache.tag==='cache_all_noleak'?'安全模式（自动识别）':cache.tag==='cache_all'?'兼容模式（自动识别）':'模式未知';
    const cacheDisabled=cacheSwitch==='B';
    const cacheHit=Math.max(0,Math.min(100,+cache.hit||0));
    const cacheValue=cacheDisabled?'已关闭':pct(cache.hit);
    const cacheNote=cacheDisabled?'核心缓存当前关闭':`核心缓存 · ${cacheModeLabel}`;
    const now=Date.now(); let qps=0;if(state.lastStats&&stats.total_queries>=state.lastStats.total_queries){qps=(stats.total_queries-state.lastStats.total_queries)/Math.max(1,(now-state.lastStatsAt)/1000)}state.lastStats=stats;state.lastStatsAt=now;
    state.history.push({t:new Date(),total:stats.total_queries,avg:+stats.average_duration_ms||0,qps});if(state.history.length>30)state.history.shift();
    const healthy=(+stats.average_duration_ms||0)<100&&success>=95;
    const healthTitle=healthy?'DNS 服务运行正常':'DNS 服务需要关注';
    const healthText=healthy?'解析服务稳定，当前关键指标处于正常范围。':'检测到延迟或成功率偏离正常范围，请查看慢查询与上游状态。';
    const ds=(sets||[]).filter(x=>x&&x.count>0);
    const slowRows=slowest?.length?`<div class="table-wrap" id="slowest-table-wrap"><table class="table-compact"><thead><tr><th>域名</th><th>类型</th><th>客户端</th><th>耗时</th></tr></thead><tbody>${slowest.map(x=>`<tr><td>${esc(x.query_name)}</td><td>${esc(x.query_type)}</td><td>${esc(state.aliases[x.client_ip]||x.client_ip)}</td><td><span class="latency-chip ${+x.duration_ms>500?'bad':''}">${ms(x.duration_ms)}</span></td></tr>`).join('')}</tbody></table></div>`:empty();

    page.innerHTML=`
      <section class="unifi-health-panel ${healthy?'is-healthy':'is-warning'}">
        <div class="unifi-health-main">
          <span class="unifi-health-orb"><span class="unifi-health-pulse"></span>${icon(healthy?'check':'warning')}</span>
          <div><div class="unifi-health-kicker"><span class="unifi-eyebrow">MOSDNS NETWORK SERVICE</span><span class="unifi-status-chip"><i></i>${healthy?'在线':'需关注'}</span></div><h2>${healthTitle}</h2><p>${healthText}</p></div>
        </div>
        <div class="unifi-health-stats">
          <div><span>平均响应</span><strong>${ms(stats.average_duration_ms)}</strong><small>${(+stats.average_duration_ms||0)<20?'表现优秀':'实时统计'}</small></div>
          <div><span>查询成功率</span><strong>${pct(success)}</strong><small>样本 ${num(sample.length)} 条</small></div>
          <div><span>当前吞吐</span><strong>${qps.toFixed(2)} QPS</strong><small>按刷新周期计算</small></div>
        </div>
        <div class="unifi-health-actions">
          <button class="button" data-route="logs">${icon('logs')}查看日志</button>
          <button class="button primary" data-route="upstreams">${icon('upstream')}管理上游</button>
        </div>
      </section>

      <div class="unifi-kpi-strip">
        ${metricCard('累计请求',num(stats.total_queries),'审计日志总量','logs',true)}
        ${metricCard('缓存命中',cacheValue,cacheNote,'data',false,cacheDisabled?'bad':'good')}
        ${metricCard('运行时间',durationCompact(sys.uptime),status.capturing?'审计运行中':'审计已停止','system',false,status.capturing?'good':'bad')}
        ${metricCard('慢查询样本',num(slowest?.length||0),'展示最慢的 8 条','warning')}
      </div>

      <div class="unifi-dashboard-grid">
        <section class="card unifi-performance-card traffic-device-card">
          <div class="card-header"><div class="card-title"><span class="icon">${icon('system')}</span><div><h2>设备流量</h2><p>经过客户端接口的实时上下行、连接与协议</p></div></div><div class="unifi-live-pill ${traffic?.ok?'':'offline'}" id="traffic-live-pill"><span></span>${traffic?.ok?'实时':'离线'}</div></div>
          <div class="card-body" id="traffic-panel-body">${trafficPanelBody(traffic)}</div>
        </section>


        <section class="card unifi-routing-card">
          <div class="card-header"><div class="card-title"><span class="icon">${icon('rules')}</span><div><h2>分流结果</h2><p>按 domain_set 分类</p></div></div></div>
          <div class="card-body"><div class="overview-donut-wrap"><div class="overview-donut-canvas"><canvas id="overview-donut"></canvas><div class="unifi-donut-center"><strong>${compactNum(ds.reduce((n,x)=>n+(+x.count||0),0))}</strong><span>已分类请求</span></div></div><div class="overview-donut-legend" id="overview-donut-legend"></div></div></div>
        </section>

        ${card('客户端排行',rankRows(clients,x=>state.aliases[x.key]||x.key),{iconName:'system',actions:'<button class="button small" id="manage-alias">管理别名</button>',className:'unifi-client-card'})}
        ${card('域名排行',rankRows(domains),{iconName:'upstream',className:'unifi-domain-card'})}
        ${card('最慢查询',slowRows,{iconName:'logs',subtitle:'用于定位上游、网络或规则处理延迟',actions:'<button class="button small" data-route="logs">查看全部日志</button>',className:'unifi-slowest-card'})}
      </div>`;

    const c=chartColors();
    const donutColors=[c.primary,c.pink,c.cyan,c.orange,c.green,'#8b5cf6','#ef4444','#eab308','#3b82f6','#10b981','#ec4899','#06b6d4','#f43f5e','#a855f7','#14b8a6','#f59e0b'];
    chart($('#overview-donut'),{type:'doughnut',data:{labels:ds.map(x=>x.key||'未分类'),datasets:[{data:ds.map(x=>x.count),backgroundColor:ds.map((_,i)=>donutColors[i%donutColors.length]),borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,cutout:'68%',plugins:{legend:{display:false}}}});
    const legend=$('#overview-donut-legend');
    if(legend){legend.innerHTML=ds.length?ds.map((x,i)=>`<div class="legend-item"><span class="legend-main"><span class="legend-swatch" style="background:${donutColors[i%donutColors.length]}"></span><span class="legend-label" title="${esc(x.key||'未分类')}">${esc(x.key||'未分类')}</span></span><span class="legend-value">${num(x.count)}</span></div>`).join(''):`<div class="empty-state" style="min-height:120px"><div><div class="empty-icon">${icon('rules')}</div><strong>暂无分流数据</strong><p>等待采样后会显示分类统计。</p></div></div>`;}
    $('#manage-alias').onclick=openAliasModal; loadAliases().catch(()=>{}); state.trafficLatest=traffic; bindTrafficSort(); bindTrafficDetail(); updateTrafficChart(traffic); startTrafficPolling();
  }

  function logBadge(set){const s=String(set||'未分类');let cls='primary';if(/黑|BAN|BLOCK|拒绝/i.test(s))cls='danger';else if(/白|直连|国内|REAL/i.test(s))cls='success';else if(/灰|代理|订阅/i.test(s))cls='pink';else if(/FAKE/i.test(s))cls='cyan';return `<span class="badge ${cls}">${esc(s)}</span>`;}
  function logRow(x){const ans=(x.answers||[]).map(a=>a.data||a.value).filter(Boolean).join(', ')||x.response_code||'—';return `<tr data-log='${esc(JSON.stringify(x))}'><td>${fmtDate(x.query_time)}</td><td><strong>${esc(x.query_name)}</strong><div style="color:var(--muted);font-size:11px;max-width:360px;overflow:hidden;text-overflow:ellipsis">${esc(ans)}</div></td><td>${esc(x.query_type)}</td><td>${logBadge(x.domain_set)}</td><td>${ms(x.duration_ms)}</td><td>${esc(state.aliases[x.client_ip]||x.client_ip)}</td><td><span class="badge ${x.response_code==='NOERROR'?'success':'danger'}">${esc(x.response_code)}</span></td><td><button class="button small log-detail">详情</button></td></tr>`;}
  async function renderLogs(){
    const p=state.logs; const data=await api.logs({page:p.page,limit:p.limit,q:p.q,exact:p.exact}); let rows=data.logs||[];
    rows=rows.filter(x=>(!p.type||x.query_type===p.type)&&(!p.set||x.domain_set===p.set)&&(!p.code||x.response_code===p.code)&&(!p.client||x.client_ip.includes(p.client)));
    const types=[...new Set((data.logs||[]).map(x=>x.query_type).filter(Boolean))],sets=[...new Set((data.logs||[]).map(x=>x.domain_set).filter(Boolean))],codes=[...new Set((data.logs||[]).map(x=>x.response_code).filter(Boolean))];
    page.innerHTML=`${card('查询与过滤日志',`<div class="toolbar"><div class="field toolbar-grow"><label>全局搜索</label><div class="search-input"><span class="search-icon">${icon('search')}</span><input id="log-q" value="${esc(p.q)}" placeholder='域名、IP；使用精确匹配可查完整值'></div></div><div class="field"><label>请求类型</label><select id="log-type"><option value="">全部</option>${types.map(x=>`<option ${p.type===x?'selected':''}>${esc(x)}</option>`).join('')}</select></div><div class="field"><label>分流结果</label><select id="log-set"><option value="">全部</option>${sets.map(x=>`<option ${p.set===x?'selected':''}>${esc(x)}</option>`).join('')}</select></div><div class="field"><label>状态</label><select id="log-code"><option value="">全部</option>${codes.map(x=>`<option ${p.code===x?'selected':''}>${esc(x)}</option>`).join('')}</select></div><div class="field"><label>客户端</label><input id="log-client" value="${esc(p.client)}" placeholder="IP"></div><label class="switch" style="align-self:center"><input id="log-exact" type="checkbox" ${p.exact?'checked':''}><span class="switch-track"><span class="switch-thumb"></span></span><span class="switch-label">精确匹配</span></label><button class="button primary" id="log-search">${icon('search')}查询</button></div>`,{iconName:'logs',actions:'<button class="button small" id="audit-control">审计控制</button><button class="button small" id="alias-control">客户端别名</button>'})}
    <div style="height:16px"></div>
    ${card('DNS 请求记录',`<div class="table-wrap"><table><thead><tr><th>时间</th><th>域名 / 响应</th><th>类型</th><th>分流</th><th>耗时</th><th>客户端</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows.length?rows.map(logRow).join(''):`<tr><td colspan="8" class="table-empty">没有符合条件的日志</td></tr>`}</tbody></table></div>${paginationHtml(data.pagination)}`,{iconName:'logs',subtitle:`共 ${num(data.pagination?.total_items||0)} 条记录`})}`;
    $('#log-search').onclick=()=>{Object.assign(state.logs,{page:1,q:$('#log-q').value.trim(),exact:$('#log-exact').checked,type:$('#log-type').value,set:$('#log-set').value,code:$('#log-code').value,client:$('#log-client').value.trim()});renderRoute(true)};
    $('#log-q').onkeydown=e=>{if(e.key==='Enter')$('#log-search').click()};
    $$('.log-detail').forEach(b=>b.onclick=()=>{const x=JSON.parse(b.closest('tr').dataset.log);openDrawer('查询详情',x.query_name,logDetailHtml(x))});
    $$('.pagination button[data-page]').forEach(b=>b.onclick=()=>{state.logs.page=+b.dataset.page;renderRoute(true)});
    $('#audit-control').onclick=openAuditModal; $('#alias-control').onclick=openAliasModal;
  }
  function paginationHtml(p){if(!p||p.total_pages<=1)return'';const cur=p.current_page,total=p.total_pages;let arr=[];for(let i=Math.max(1,cur-2);i<=Math.min(total,cur+2);i++)arr.push(i);return `<div class="pagination"><button data-page="${cur-1}" ${cur<=1?'disabled':''}>‹</button>${arr.map(i=>`<button data-page="${i}" class="${i===cur?'active':''}">${i}</button>`).join('')}<button data-page="${cur+1}" ${cur>=total?'disabled':''}>›</button></div>`;}
  function logDetailHtml(x){const answers=(x.answers||[]).length?`<pre>${esc(JSON.stringify(x.answers,null,2))}</pre>`:'暂无响应记录';return `<div class="kv-list"><div class="kv-row"><span class="kv-key">查询时间</span><span class="kv-value">${fmtDate(x.query_time)}</span></div><div class="kv-row"><span class="kv-key">客户端</span><span class="kv-value">${esc(state.aliases[x.client_ip]||x.client_ip)}</span></div><div class="kv-row"><span class="kv-key">类型 / 类别</span><span class="kv-value">${esc(x.query_type)} / ${esc(x.query_class)}</span></div><div class="kv-row"><span class="kv-key">分流结果</span><span class="kv-value">${logBadge(x.domain_set)}</span></div><div class="kv-row"><span class="kv-key">响应码</span><span class="kv-value">${esc(x.response_code)}</span></div><div class="kv-row"><span class="kv-key">耗时</span><span class="kv-value">${ms(x.duration_ms)}</span></div><div class="kv-row"><span class="kv-key">Trace ID</span><span class="kv-value">${esc(x.trace_id||'—')}</span></div></div><h3>响应内容</h3>${answers}`;}

  async function renderUpstreams(){
    const [cfg,tags,metricsRaw]=await Promise.all([api.request('/api/v1/upstream/config'),api.request('/api/v1/upstream/tags'),api.metrics()]);state.upstreamConfig=cfg;const metrics=parseProm(metricsRaw);
    const groups=(tags||Object.keys(cfg||{})); const rows=[];groups.forEach(g=>(cfg[g]||[]).forEach((u,i)=>rows.push({g,u,i,m:upstreamMetrics(metrics,g,u.tag)})));
    page.innerHTML=`${card('上游 DNS 管理',`<div class="table-wrap upstream-table-wrap"><table class="upstream-rules-table"><colgroup><col class="col-enabled"><col class="col-group"><col class="col-name"><col class="col-protocol"><col class="col-address"><col class="col-latency"><col class="col-query"><col class="col-win"><col class="col-error"><col class="col-success"><col class="col-actions"></colgroup><thead><tr><th>启用</th><th>所属组</th><th>名称</th><th>协议</th><th>地址</th><th>平均响应</th><th>请求数</th><th>采纳数</th><th>错误数</th><th>成功率</th><th>操作</th></tr></thead><tbody>${rows.length?rows.map(({g,u,i,m})=>`<tr data-group="${esc(g)}" data-index="${i}"><td class="up-enabled-cell"><label class="switch"><input class="up-toggle" type="checkbox" ${u.enabled!==false?'checked':''}><span class="switch-track"><span class="switch-thumb"></span></span></label></td><td class="up-group-cell">${esc(g)}</td><td class="up-name-cell" title="${esc(u.tag)}"><strong>${esc(u.tag)}</strong></td><td class="up-protocol-cell"><span class="badge primary">${esc(u.protocol)}</span></td><td class="up-address-cell" title="${esc(u.addr||u.server_addr||'')}"><span class="table-ellipsis">${esc(u.addr||u.server_addr||'—')}</span></td><td class="up-latency-cell">${ms(m.latency)}</td><td class="up-query-cell">${num(m.q)}</td><td class="up-win-cell">${num(m.win)}</td><td class="up-error-cell" style="color:${m.err?'var(--red)':'var(--green)'}">${num(m.err)}</td><td class="up-success-cell">${pct(m.success)}</td><td class="up-actions-cell"><div class="table-row-actions"><button class="button small up-edit">${icon('edit')}编辑</button><button class="button small danger up-delete">${icon('trash')}删除</button></div></td></tr>`).join(''):`<tr><td colspan="11" class="table-empty">暂无上游 DNS</td></tr>`}</tbody></table></div>`,{iconName:'upstream',subtitle:'请求数、采纳数和错误数使用二进制的真实统计口径',actions:'<button class="button" id="up-restart">重启 MosDNS</button><button class="button primary" id="up-add">'+icon('plus')+'添加上游</button>'})}`;
    $$('.up-toggle').forEach(x=>x.onchange=()=>toggleUpstream(x.closest('tr'),x.checked));$$('.up-edit').forEach(x=>x.onclick=()=>openUpstreamModal(x.closest('tr')));$$('.up-delete').forEach(x=>x.onclick=()=>deleteUpstream(x.closest('tr')));$('#up-add').onclick=()=>openUpstreamModal();$('#up-restart').onclick=restartService;
  }
  async function saveUpstreamGroup(group){return api.json('/api/v1/upstream/config','POST',{plugin_tag:group,upstreams:state.upstreamConfig[group]||[]});}
  async function toggleUpstream(row,enabled){const g=row.dataset.group,i=+row.dataset.index,old=state.upstreamConfig[g][i].enabled;state.upstreamConfig[g][i].enabled=enabled;try{await saveUpstreamGroup(g);toast('上游状态已保存')}catch(e){state.upstreamConfig[g][i].enabled=old;toast('保存失败','error',e.message);renderRoute(true)}}
  async function deleteUpstream(row){if(!confirm('确定删除这个上游 DNS 吗？'))return;const g=row.dataset.group,i=+row.dataset.index,old=state.upstreamConfig[g].slice();state.upstreamConfig[g].splice(i,1);try{await saveUpstreamGroup(g);toast('上游已删除');renderRoute(true)}catch(e){state.upstreamConfig[g]=old;toast('删除失败','error',e.message)}}
  function openUpstreamModal(row){
    const edit=!!row;
    const group=edit?row.dataset.group:Object.keys(state.upstreamConfig||{})[0]||'domestic';
    const idx=edit?+row.dataset.index:-1;
    const u=edit?state.upstreamConfig[group][idx]:{tag:'',protocol:'udp',addr:'',enabled:true};
    const groups=Object.keys(state.upstreamConfig||{});
    const aliapiFields=`<details class="advanced-fields" ${u.protocol==='aliapi'?'open':''}>
      <summary>AliAPI 专用参数</summary>
      <div class="grid grid-2 advanced-fields-body">
        <div class="field"><label>Account ID</label><input id="u-account-id" value="${esc(u.account_id||'')}"></div>
        <div class="field"><label>Access Key ID</label><input id="u-access-key-id" value="${esc(u.access_key_id||'')}"></div>
        <div class="field"><label>Access Key Secret</label><input id="u-access-key-secret" type="password" value="${esc(u.access_key_secret||'')}"></div>
        <div class="field"><label>服务地址</label><input id="u-server-addr" value="${esc(u.server_addr||u.addr||'')}"></div>
        <div class="field"><label>ECS Client IP</label><input id="u-ecs-ip" value="${esc(u.ecs_client_ip||'')}"></div>
        <div class="field"><label>ECS 掩码</label><input id="u-ecs-mask" type="number" value="${esc(u.ecs_client_mask||u.ecs_mask||0)}"></div>
      </div>
    </details>`;
    modalOpen(edit?'编辑上游 DNS':'添加上游 DNS','保存后建议重启 MosDNS，使全部连接使用新配置',`<div class="grid grid-2">
      <div class="field"><label>所属组</label><select id="u-group" ${edit?'disabled':''}>${groups.map(g=>`<option ${g===group?'selected':''}>${esc(g)}</option>`).join('')}</select></div>
      <div class="field"><label>名称</label><input id="u-tag" value="${esc(u.tag||'')}" required></div>
      <div class="field"><label>协议</label><select id="u-protocol">${['udp','tcp','tls','https','quic','aliapi'].map(v=>`<option ${v===u.protocol?'selected':''}>${v}</option>`).join('')}</select></div>
      <div class="field"><label>服务器地址</label><input id="u-addr" value="${esc(u.addr||u.server_addr||'')}" placeholder="223.5.5.5:53 或 https://.../dns-query"></div>
      <div class="field"><label>拨号地址</label><input id="u-dial" value="${esc(u.dial_addr||'')}" placeholder="可选"></div>
      <div class="field"><label>SOCKS5</label><input id="u-socks" value="${esc(u.socks5||'')}" placeholder="可选"></div>
      <div class="field"><label>Bootstrap</label><input id="u-bootstrap" value="${esc(u.bootstrap||'')}" placeholder="可选"></div>
      <div class="field"><label>查询超时（ms）</label><input id="u-timeout" type="number" min="0" value="${esc(u.upstream_query_timeout||0)}"></div>
    </div>${aliapiFields}`,async()=>{
      const g=$('#u-group').value;
      const protocol=$('#u-protocol').value;
      const item=Object.assign({},u,{tag:$('#u-tag').value.trim(),protocol,enabled:u.enabled!==false});
      if(!item.tag)throw new Error('名称不能为空');
      if(protocol==='aliapi'){
        item.server_addr=$('#u-server-addr').value.trim()||$('#u-addr').value.trim();
        item.account_id=$('#u-account-id').value.trim();
        item.access_key_id=$('#u-access-key-id').value.trim();
        item.access_key_secret=$('#u-access-key-secret').value;
        item.ecs_client_ip=$('#u-ecs-ip').value.trim();
        item.ecs_client_mask=+$('#u-ecs-mask').value||0;
        delete item.addr;
      }else{
        item.addr=$('#u-addr').value.trim();
        item.dial_addr=$('#u-dial').value.trim();
        item.socks5=$('#u-socks').value.trim();
        item.bootstrap=$('#u-bootstrap').value.trim();
        item.upstream_query_timeout=+$('#u-timeout').value||0;
      }
      if(edit)state.upstreamConfig[g][idx]=item;
      else(state.upstreamConfig[g]||(state.upstreamConfig[g]=[])).push(item);
      await saveUpstreamGroup(g);
      toast('上游 DNS 已保存');
      renderRoute(true);
    });
    const protocolSelect=$('#u-protocol');
    const advanced=$('.advanced-fields');
    protocolSelect.onchange=()=>{if(protocolSelect.value==='aliapi')advanced.open=true};
  }

  const ruleProfiles=[['whitelist','白名单'],['blocklist','黑名单'],['greylist','灰名单'],['realiplist','强制 RealIP'],['ddnslist','DDNS 域名'],['pcdnlist','PCDN 域名'],['pcdnregv4','PCDN IPv4 规则'],['pcdnregv6','PCDN IPv6 规则'],['client_ip','客户端 IP'],['direct_ip','直连 IP'],['rewrite','重定向']];
  async function renderRules(){
    page.innerHTML=`<div class="tabs" id="rule-top-tabs"><button class="tab active" data-rule-tab="lists">名单管理</button><button class="tab" data-rule-tab="adguard">广告拦截</button><button class="tab" data-rule-tab="diversion">在线分流</button></div><div id="rule-tab-body" style="margin-top:16px"></div>`;$$('[data-rule-tab]').forEach(x=>x.onclick=()=>{$$('[data-rule-tab]').forEach(y=>y.classList.toggle('active',y===x));renderRuleTab(x.dataset.ruleTab)});await renderRuleTab('lists');
  }
  async function renderRuleTab(tab){const body=$('#rule-tab-body');body.innerHTML=loadingPage();if(tab==='lists')return renderListRules(body);if(tab==='adguard')return renderAdguard(body);return renderDiversion(body);}
  async function renderListRules(body){if(!ruleProfiles.some(x=>x[0]===state.ruleTag))state.ruleTag=ruleProfiles[0][0];const tag=state.ruleTag;let text='';try{text=await api.request(`/plugins/${tag}/show?limit=10000`)}catch(e){text=`加载失败：${e.message}`};const profile=ruleProfiles.find(x=>x[0]===tag)||ruleProfiles[0];body.innerHTML=`<section class="card"><div class="rule-layout"><div class="rule-menu">${ruleProfiles.map(([t,n])=>`<button data-rule-tag="${t}" class="${t===tag?'active':''}"><span>${n}</span><span class="rule-count"></span></button>`).join('')}</div><div class="rule-editor"><div class="section-header"><div><h2>${profile[1]}</h2><p>一行一条；支持当前插件原有的规则语法</p></div><button class="button primary" id="rule-save">${icon('save')}保存</button></div><textarea id="rule-text" class="rule-textarea" spellcheck="false">${esc(String(text).trim())}</textarea><div class="rule-editor-footer"><span id="rule-lines">共 ${String(text).trim()?String(text).trim().split('\n').length:0} 行</span><button class="button small" id="rule-download">${icon('download')}下载列表</button></div></div></div></section>`;$$('[data-rule-tag]').forEach(x=>x.onclick=()=>{state.ruleTag=x.dataset.ruleTag;renderListRules(body)});$('#rule-text').oninput=()=>$('#rule-lines').textContent=`共 ${$('#rule-text').value.split('\n').filter(Boolean).length} 行`;$('#rule-save').onclick=async()=>{const values=$('#rule-text').value.split('\n').map(x=>x.trim()).filter(Boolean);try{await api.json(`/plugins/${tag}/post`,'POST',{values});toast(`${profile[1]}已保存`)}catch(e){toast('保存失败','error',e.message)}};$('#rule-download').onclick=()=>downloadText(`${tag}.txt`,$('#rule-text').value);requestAnimationFrame(fitRuleLayoutHeight);}
  async function renderAdguard(body){
    const rules=await api.request('/plugins/adguard/rules');
    body.innerHTML=card('广告拦截规则',`<div class="table-wrap adguard-table-wrap"><table class="adguard-rules-table"><colgroup><col class="col-enabled"><col class="col-name"><col class="col-url"><col class="col-count"><col class="col-auto"><col class="col-updated"><col class="col-actions"></colgroup><thead><tr><th>启用</th><th>名称</th><th>订阅地址</th><th>规则数</th><th>自动更新</th><th>上次更新</th><th>操作</th></tr></thead><tbody>${rules.length?rules.map(r=>`<tr data-id="${esc(r.id)}"><td class="ad-enabled-cell"><label class="switch"><input class="ad-enable" type="checkbox" ${r.enabled?'checked':''}><span class="switch-track"><span class="switch-thumb"></span></span></label></td><td class="ad-name-cell" title="${esc(r.name)}"><strong>${esc(r.name)}</strong></td><td class="ad-url-cell" title="${esc(r.url)}"><span class="table-ellipsis">${esc(r.url)}</span></td><td class="ad-count-cell">${num(r.rule_count)}</td><td class="ad-auto-cell">${r.auto_update?'是':'否'}</td><td class="ad-updated-cell">${fmtDate(r.last_updated)}</td><td class="ad-actions-cell"><div class="table-row-actions"><button class="button small ad-edit">${icon('edit')}编辑</button><button class="button small danger ad-delete">${icon('trash')}删除</button></div></td></tr>`).join(''):`<tr><td colspan="7" class="table-empty">暂无规则</td></tr>`}</tbody></table></div>`,{iconName:'rules',actions:'<button class="button" id="ad-update-all">更新全部</button><button class="button primary" id="ad-add">'+icon('plus')+'添加订阅</button>'});
    $$('.ad-enable').forEach(x=>x.onchange=()=>updateAdguard(rules.find(r=>String(r.id)===x.closest('tr').dataset.id),{enabled:x.checked}));
    $$('.ad-edit').forEach(x=>x.onclick=()=>openAdguardModal(rules.find(r=>String(r.id)===x.closest('tr').dataset.id),body));
    $$('.ad-delete').forEach(x=>x.onclick=async()=>{if(!confirm('确定删除？'))return;await api.request(`/plugins/adguard/rules/${x.closest('tr').dataset.id}`,{method:'DELETE'});toast('已删除');renderAdguard(body)});
    $('#ad-update-all').onclick=async()=>{await api.request('/plugins/adguard/update',{method:'POST'});toast('全部广告规则更新任务已提交')};
    $('#ad-add').onclick=()=>openAdguardModal(null,body);
  }
  async function updateAdguard(rule,patch){const next=Object.assign({},rule,patch);await api.json(`/plugins/adguard/rules/${rule.id}`,'PUT',next);toast('规则状态已保存')}
  function openAdguardModal(rule,body){rule=rule||{name:'',url:'',enabled:true,auto_update:true,update_interval_hours:24};modalOpen(rule.id?'编辑广告规则':'添加广告规则','在线规则将由 AdGuard 插件管理',`<div class="stack"><div class="field"><label>名称</label><input id="ad-name" value="${esc(rule.name)}"></div><div class="field"><label>订阅地址</label><input id="ad-url" value="${esc(rule.url)}"></div><div class="grid grid-2"><label class="switch"><input id="ad-enabled" type="checkbox" ${rule.enabled?'checked':''}><span class="switch-track"><span class="switch-thumb"></span></span><span class="switch-label">启用</span></label><label class="switch"><input id="ad-auto" type="checkbox" ${rule.auto_update?'checked':''}><span class="switch-track"><span class="switch-thumb"></span></span><span class="switch-label">自动更新</span></label></div><div class="field"><label>更新间隔（小时）</label><input id="ad-hours" type="number" value="${rule.update_interval_hours||24}"></div></div>`,async()=>{const payload={name:$('#ad-name').value.trim(),url:$('#ad-url').value.trim(),enabled:$('#ad-enabled').checked,auto_update:$('#ad-auto').checked,update_interval_hours:+$('#ad-hours').value||24};if(!payload.name||!payload.url)throw new Error('名称和地址不能为空');if(rule.id)await api.json(`/plugins/adguard/rules/${rule.id}`,'PUT',Object.assign({},rule,payload));else await api.json('/plugins/adguard/rules','POST',payload);toast('广告规则已保存');renderAdguard(body)});}
  const diversionDefs=[
    {tag:'cuscn',type:'cuscn',label:'国内规则'},
    {tag:'cusnocn',type:'cusnocn',label:'国外规则'},
    {tag:'geoip_cn',type:'geoipcn',label:'GeoIP CN'},
    {tag:'geosite_cn',type:'geositecn',label:'Geosite CN'},
    {tag:'geosite_no_cn',type:'geositenocn',label:'Geosite 非 CN'}
  ];
  const diversionDefByTag=tag=>diversionDefs.find(x=>x.tag===tag);
  const diversionDefByType=type=>diversionDefs.find(x=>x.type===type);
  function diversionPayload(rule){
    const payload={
      name:String(rule.name||'').trim(), type:String(rule.type||'').trim(),
      files:String(rule.files||'').trim(), url:String(rule.url||'').trim(),
      auto_update:Boolean(rule.auto_update), update_interval_hours:+rule.update_interval_hours||24,
      enabled:rule.enabled!==false
    };
    if(rule.rule_count!==undefined&&rule.rule_count!==null)payload.rule_count=+rule.rule_count||0;
    if(rule.last_updated)payload.last_updated=rule.last_updated;
    return payload;
  }
  function defaultDiversionFile(name){
    const slug=String(name||'rule').trim().replace(/[^a-zA-Z0-9._-]+/g,'_').replace(/^_+|_+$/g,'')||'rule';
    return `srs/${slug}.srs`;
  }
  async function saveDiversionRule(rule,original=null){
    const target=diversionDefByType(rule.type);if(!target)throw new Error('请选择有效的规则类型');
    const payload=diversionPayload(rule);if(!payload.name)throw new Error('名称不能为空');if(!payload.url&&!payload.files)throw new Error('订阅地址和本地文件至少填写一项');
    if(!payload.files&&payload.url)payload.files=defaultDiversionFile(payload.name);
    await api.json(`/plugins/${target.tag}/config/${encodeURIComponent(payload.name)}`,'PUT',payload);
    if(original&&(original.tag!==target.tag||original.name!==payload.name)){
      await api.request(`/plugins/${original.tag}/config/${encodeURIComponent(original.name)}`,{method:'DELETE'});
    }
  }
  async function renderDiversion(body){
    const all=await Promise.all(diversionDefs.map(async def=>{try{return{def,items:await api.request(`/plugins/${def.tag}/config`)}}catch{return{def,items:[]}}}));
    const rows=all.flatMap(({def,items})=>(Array.isArray(items)?items:[]).map(i=>({
      ...i,tag:def.tag,group:def.label,type:i.type||def.type,enabled:i.enabled!==false,
      auto_update:Boolean(i.auto_update),update_interval_hours:+i.update_interval_hours||24
    })));
    body.innerHTML=card('在线分流规则',`<div class="table-wrap diversion-table-wrap"><table class="diversion-rules-table"><colgroup><col class="col-enabled"><col class="col-type"><col class="col-name"><col class="col-url"><col class="col-count"><col class="col-auto"><col class="col-updated"><col class="col-actions"></colgroup><thead><tr><th>启用</th><th>类型</th><th>名称</th><th>订阅地址</th><th>规则数</th><th>自动更新</th><th>上次更新</th><th>操作</th></tr></thead><tbody>${rows.length?rows.map(r=>{const source=r.url||r.files||r.path||'—';return `<tr data-tag="${esc(r.tag)}" data-name="${esc(r.name)}"><td class="rule-enabled-cell"><label class="switch"><input class="div-enable" type="checkbox" ${r.enabled?'checked':''}><span class="switch-track"><span class="switch-thumb"></span></span></label></td><td class="rule-type-cell">${esc(r.group)}</td><td class="rule-name-cell">${esc(r.name)}</td><td class="rule-url-cell" title="${esc(source)}"><span class="rule-url-text">${esc(source)}</span></td><td class="rule-count-cell">${num(r.rule_count||r.count||0)}</td><td class="rule-auto-cell">${r.auto_update?'是':'否'}</td><td class="rule-date-cell">${fmtDate(r.last_updated||r.updated_at)}</td><td class="rule-actions-cell"><div class="rule-row-actions"><button class="button small div-update">更新</button><button class="button small div-edit">编辑</button><button class="button small danger div-delete">删除</button></div></td></tr>`}).join(''):`<tr><td colspan="8" class="table-empty">暂无在线规则或插件未启用</td></tr>`}</tbody></table></div>`,{iconName:'rules',actions:'<button class="button" id="div-update-all">更新全部</button><button class="button primary" id="div-add">'+icon('plus')+'添加规则</button>'});
    const findRow=tr=>rows.find(r=>r.tag===tr.dataset.tag&&String(r.name)===tr.dataset.name);
    $$('.div-enable').forEach(x=>x.onchange=async()=>{const tr=x.closest('tr'),rule=findRow(tr);if(!rule)return;x.disabled=true;try{const next={...rule,enabled:x.checked};await saveDiversionRule(next,rule);rule.enabled=x.checked;toast(`规则“${rule.name}”已${x.checked?'启用':'关闭'}，配置已保存`)}catch(e){x.checked=!x.checked;toast('状态保存失败','error',e.message)}finally{x.disabled=false}});
    $$('.div-update').forEach(x=>x.onclick=async()=>{const tr=x.closest('tr');x.disabled=true;try{await api.request(`/plugins/${tr.dataset.tag}/update/${encodeURIComponent(tr.dataset.name)}`,{method:'POST'});toast('更新任务已提交')}catch(e){toast('更新失败','error',e.message)}finally{x.disabled=false}});
    $$('.div-edit').forEach(x=>x.onclick=()=>{const rule=findRow(x.closest('tr'));if(rule)openDiversionModal(rule,body)});
    $$('.div-delete').forEach(x=>x.onclick=async()=>{if(!confirm('确定删除此在线规则？配置文件中的对应项目也会被删除。'))return;const tr=x.closest('tr');await api.request(`/plugins/${tr.dataset.tag}/config/${encodeURIComponent(tr.dataset.name)}`,{method:'DELETE'});toast('规则及对应配置已删除');renderDiversion(body)});
    $('#div-add').onclick=()=>openDiversionModal(null,body);
    $('#div-update-all').onclick=async()=>{const targets=rows.filter(r=>r.enabled&&(r.url||r.files));if(!targets.length){toast('没有可更新的已启用规则','info');return}const btn=$('#div-update-all');btn.disabled=true;try{const result=await Promise.allSettled(targets.map(r=>api.request(`/plugins/${r.tag}/update/${encodeURIComponent(r.name)}`,{method:'POST'})));const failed=result.filter(x=>x.status==='rejected').length;failed?toast(`已提交 ${result.length-failed} 条，失败 ${failed} 条`,'error'):toast(`已提交 ${result.length} 条在线分流规则更新任务`)}finally{btn.disabled=false}};
  }
  function openDiversionModal(rule,body){
    const original=rule?{...rule}:null;rule=rule||{name:'',type:'cuscn',url:'',files:'',enabled:true,auto_update:true,update_interval_hours:24};
    modalOpen(original?'编辑在线分流规则':'添加在线分流规则','保存后会同步写入 MosDNS 对应分流插件的服务器端配置',`<div class="stack"><div class="grid grid-2"><div class="field"><label>名称</label><input id="div-name" value="${esc(rule.name)}" placeholder="例如：telegram"></div><div class="field"><label>规则类型</label><select id="div-type">${diversionDefs.map(d=>`<option value="${d.type}" ${d.type===rule.type?'selected':''}>${esc(d.label)}</option>`).join('')}</select></div></div><div class="field"><label>订阅地址</label><input id="div-url" value="${esc(rule.url||'')}" placeholder="https://example.com/rules.srs"></div><div class="field"><label>本地文件</label><input id="div-files" value="${esc(rule.files||'')}" placeholder="可选，按原插件格式填写"></div><div class="grid grid-2"><label class="switch"><input id="div-enabled" type="checkbox" ${rule.enabled!==false?'checked':''}><span class="switch-track"><span class="switch-thumb"></span></span><span class="switch-label">启用</span></label><label class="switch"><input id="div-auto" type="checkbox" ${rule.auto_update?'checked':''}><span class="switch-track"><span class="switch-thumb"></span></span><span class="switch-label">自动更新</span></label></div><div class="field"><label>更新间隔（小时）</label><input id="div-hours" type="number" min="1" value="${rule.update_interval_hours||24}"></div></div>`,async()=>{const payload={name:$('#div-name').value.trim(),type:$('#div-type').value,url:$('#div-url').value.trim(),files:$('#div-files').value.trim(),enabled:$('#div-enabled').checked,auto_update:$('#div-auto').checked,update_interval_hours:+$('#div-hours').value||24};await saveDiversionRule(payload,original);toast(`在线分流规则已${original?'更新':'添加'}，服务器配置已同步保存`);await renderDiversion(body);if(!original)setTimeout(()=>renderDiversion(body),5000)});
  }

  async function renderData(){
    const [metricsRaw,reqStatus,reqCfg,counts]=await Promise.all([
      api.metrics(),
      safe(()=>api.request('/plugins/requery/status'),null),
      safe(()=>api.request('/plugins/requery/'),null),
      safe(()=>api.request('/plugins/requery/stats/source_file_counts'),null)
    ]);
    const metrics=parseProm(metricsRaw),caches=parseCaches(metrics);
    const cachePanel=`<section class="card data-cache-panel"><div class="card-header"><div class="card-title"><span class="icon">${icon('data')}</span><div><h2>缓存管理</h2><p>查看命中率和条目数，可单独清空</p></div></div></div><div class="card-body"><div class="cache-grid data-cache-grid">${caches.map(c=>`<div class="cache-card"><h3>${cacheName(c.tag)}</h3><div class="cache-stats"><div class="cache-stat" title="完整数值：${num(c.q)}"><span>请求总数</span><strong>${compactNum(c.q)}</strong></div><div class="cache-stat" title="完整数值：${num(c.size)}"><span>条目数</span><strong>${compactNum(c.size)}</strong></div><div class="cache-stat" title="完整数值：${pct(c.hit)}"><span>命中率</span><strong>${compactPct(c.hit)}</strong></div><div class="cache-stat" title="完整数值：${pct(c.lazy)}"><span>过期命中</span><strong>${compactPct(c.lazy)}</strong></div></div><div class="card-actions" style="margin-top:12px"><button class="button small cache-view" data-tag="${c.tag}">查看</button><button class="button small danger cache-clear" data-tag="${c.tag}">清空</button></div></div>`).join('')}</div></div></section>`;
    const requeryCard=card('刷新分流缓存',requeryHtml(reqStatus,reqCfg),{
      iconName:'refresh',
      subtitle:'重新扫描域名并更新自动生成的分流列表',
      className:'data-requery-card'
    });
    const countsCard=card('域名列表统计',`${countsHtml(counts)}<div class="data-counts-actions"><button class="button" id="save-shunt">保存分流规则</button><button class="button danger" id="clear-shunt">清空分流规则</button></div>`,{
      iconName:'rules',
      subtitle:'查看自动分流列表的当前条目数',
      className:'data-counts-card'
    });
    page.innerHTML=`<div class="grid data-layout">${cachePanel}<div class="data-side-column">${requeryCard}${countsCard}</div></div>`;

    $$('.cache-clear').forEach(x=>x.onclick=async()=>{
      if(!confirm(`确定清空 ${cacheName(x.dataset.tag)}？`))return;
      await api.request(`/plugins/${x.dataset.tag}/flush`);
      toast('缓存已清空');
      renderRoute(true)
    });
    $$('.cache-view').forEach(x=>x.onclick=async()=>{
      const text=await api.request(`/plugins/${x.dataset.tag}/show`);
      openDrawer(cacheName(x.dataset.tag),'缓存内容',`<pre>${esc(text)}</pre>`)
    });
    $('#requery-trigger')?.addEventListener('click',async()=>{
      await api.request('/plugins/requery/trigger',{method:'POST'});
      toast('刷新任务已开始');
      renderRoute(true)
    });
    $('#requery-cancel')?.addEventListener('click',async()=>{
      await api.request('/plugins/requery/cancel',{method:'POST'});
      toast('已请求取消');
      renderRoute(true)
    });
    $('#requery-scheduler')?.addEventListener('click',()=>openRequeryScheduler(reqCfg));
    $('#save-shunt')?.addEventListener('click',()=>multiPluginAction(['top_domains/save','my_fakeiplist/save','my_nodenov4list/save','my_nodenov6list/save','my_nov4list/save','my_nov6list/save','my_realiplist/save'],'分流规则已保存'));
    $('#clear-shunt')?.addEventListener('click',()=>{
      if(confirm('确定清空自动生成的分流规则？域名全集记录会保留。'))multiPluginAction(['my_fakeiplist/flush','my_nodenov4list/flush','my_nodenov6list/flush','my_nov4list/flush','my_nov6list/flush','my_realiplist/flush'],'分流规则已清空')
    });
  }
  const cacheName=t=>({cache_all:'全部缓存（兼容）',cache_all_noleak:'全部缓存（安全）',cache_cn:'国内缓存',cache_google:'国外缓存（兼容）',cache_google_node:'国外缓存（安全）',cache_node:'节点缓存'})[t]||t;
  function requeryHtml(s,c){
    if(!s)return empty('Requery 插件不可用');
    const taskState=String(s.task_state||s.status||'idle').toLowerCase();
    const running=s.running===true||['running','processing','cancelling'].includes(taskState);
    const stateText={idle:'空闲',running:'运行中',processing:'运行中',cancelling:'正在取消',failed:'运行失败',error:'运行失败'}[taskState]||(running?'运行中':'空闲');
    const stateClass=['failed','error'].includes(taskState)?'danger':(running?'primary':'success');
    const pr=s.progress||{};
    const hasProgress=pr.processed!==undefined||pr.total!==undefined;
    const lastRun=s.last_run_end_time||s.last_run_start_time||s.last_run?.finished_at||s.last_run?.started_at;
    const lastCount=s.last_run_domain_count;
    return `<div class="kv-list"><div class="kv-row"><span class="kv-key">当前状态</span><span class="kv-value"><span class="badge ${stateClass}">${stateText}</span></span></div><div class="kv-row"><span class="kv-key">进度</span><span class="kv-value">${hasProgress?`${num(pr.processed??0)} / ${num(pr.total??0)}`:'—'}</span></div><div class="kv-row"><span class="kv-key">上次运行</span><span class="kv-value">${fmtDate(lastRun)}</span></div><div class="kv-row"><span class="kv-key">上次处理域名</span><span class="kv-value">${lastCount===undefined||lastCount===null?'—':num(lastCount)+' 条'}</span></div><div class="kv-row"><span class="kv-key">定时任务</span><span class="kv-value">${c?.scheduler?.enabled?'已启用':'未启用'}</span></div><div class="kv-row"><span class="kv-key">间隔</span><span class="kv-value">${c?.scheduler?.interval_minutes?num(c.scheduler.interval_minutes)+' 分钟':'—'}</span></div></div><div class="card-actions" style="margin-top:14px"><button class="button" id="requery-scheduler">定时任务设置</button>${running?'<button class="button danger" id="requery-cancel">取消任务</button>':'<button class="button primary" id="requery-trigger">开始全新任务</button>'}</div>`;
  }
  function openRequeryScheduler(c){
    c=c||{};
    const sc=c.scheduler||{};
    const dateDays=sc.date_range_days||c.execution_settings?.date_range_days||30;
    let local='';
    if(sc.start_datetime){const d=new Date(sc.start_datetime);if(!Number.isNaN(d.getTime())){const n=new Date(d.getTime()-d.getTimezoneOffset()*60000);local=n.toISOString().slice(0,16)}}
    modalOpen('分流刷新定时任务','定期扫描近期查询域名并刷新自动分流缓存',`<div class="stack"><label class="switch"><input id="rq-enabled" type="checkbox" ${sc.enabled?'checked':''}><span class="switch-track"><span class="switch-thumb"></span></span><span class="switch-label">启用定时任务</span></label><div class="grid grid-2"><div class="field"><label>执行间隔（分钟）</label><input id="rq-interval" type="number" min="1" value="${esc(sc.interval_minutes||10080)}"></div><div class="field"><label>域名刷新天数</label><input id="rq-days" type="number" min="1" value="${esc(dateDays)}"></div></div><div class="field"><label>首次执行时间</label><input id="rq-start" type="datetime-local" value="${esc(local)}"></div><p class="form-note">10080 分钟等于 7 天。首次执行时间留空时由插件按当前配置安排。</p></div>`,async()=>{
      const enabled=$('#rq-enabled').checked;
      const interval=+$('#rq-interval').value||0;
      const days=+$('#rq-days').value||0;
      if(enabled&&interval<=0)throw new Error('启用定时任务时，执行间隔必须大于 0');
      if(days<1)throw new Error('域名刷新天数必须大于 0');
      const raw=$('#rq-start').value;
      const payload={enabled,interval_minutes:interval,start_datetime:raw?new Date(raw).toISOString():'',date_range_days:days};
      await api.json('/plugins/requery/scheduler/config','POST',payload);
      toast('定时任务配置已更新');
      renderRoute(true);
    });
  }
  function countsHtml(c){
    if(!c)return empty('暂无统计');
    let raw=c;
    if(raw&&typeof raw==='object'&&!Array.isArray(raw)&&Object.prototype.hasOwnProperty.call(raw,'data')) raw=raw.data;
    if(raw&&typeof raw==='object'&&!Array.isArray(raw)){
      if(Array.isArray(raw.items)) raw=raw.items;
      else if(Array.isArray(raw.counts)) raw=raw.counts;
      else if(Array.isArray(raw.source_file_counts)) raw=raw.source_file_counts;
    }
    const entries=Array.isArray(raw)?raw:(raw&&typeof raw==='object'?Object.entries(raw).map(([name,value])=>value&&typeof value==='object'?{name,...value}:{name,count:value}):[]);
    if(!entries.length)return empty('暂无统计');
    return `<div class="table-wrap"><table><thead><tr><th>列表</th><th>条目数</th></tr></thead><tbody>${entries.map(x=>`<tr><td>${esc(x.alias||x.name||x.file||x.path||'未知')}</td><td>${num(x.count??x.rule_count??x.entries??x.value??0)}</td></tr>`).join('')}</tbody></table></div>`;
  }
  async function multiPluginAction(paths,msg){await Promise.all(paths.map(p=>api.request(`/plugins/${p}`)));toast(msg);renderRoute(true)}

  async function renderSettings(){
    const [status,cap,over]=await Promise.all([api.status(),api.capacity(),api.request('/api/v1/overrides')]);
    const replacements=Array.isArray(over.replacements)?over.replacements:[];
    const replacementRow=(r={original:'',new:'',comment:''})=>`<tr class="replacement-row"><td><input class="rep-original" value="${esc(r.original||'')}" placeholder="原值（查找）"></td><td><input class="rep-new" value="${esc(r.new||'')}" placeholder="新值（替换）"></td><td><input class="rep-comment" value="${esc(r.comment||'')}" placeholder="备注（可选）"></td><td><button class="button small danger rep-delete" type="button">删除</button></td></tr>`;
    page.innerHTML=`<div class="grid grid-3">
      ${card('审计控制',`<div class="kv-list"><div class="kv-row"><span class="kv-key">运行状态</span><span class="kv-value"><span class="badge ${status.capturing?'success':'danger'}">${status.capturing?'运行中':'已停止'}</span></span></div><div class="kv-row"><span class="kv-key">日志容量</span><span class="kv-value">${num(cap.capacity)} 条</span></div></div><div class="card-actions" style="margin-top:14px"><button class="button ${status.capturing?'danger':'success'}" id="audit-toggle">${status.capturing?'关闭审计':'开启审计'}</button><button class="button danger" id="audit-clear">清空日志</button></div>`,{iconName:'logs'})}
      ${card('日志容量',`<div class="field"><label>最大记录数</label><input id="audit-cap" type="number" min="100" value="${cap.capacity}"></div><button class="button primary" id="cap-save" style="margin-top:14px;width:100%">保存容量</button>`,{iconName:'data'})}
      ${card('自动刷新',`<div class="field"><label>界面刷新间隔（秒）</label><input id="refresh-interval" type="number" min="5" value="${CONFIG.refreshInterval}"></div><p class="form-note">只影响外部 UI，不修改 MosDNS。</p>`,{iconName:'refresh'})}
    </div><div style="height:16px"></div>
    ${card('覆盖配置',`<div class="grid grid-2"><div class="field"><label>SOCKS5 代理</label><input id="set-socks" value="${esc(over.socks5||'')}" placeholder="127.0.0.1:9666"></div><div class="field"><label>ECS IP</label><input id="set-ecs" value="${esc(over.ecs||'')}" placeholder="IPv4 或 IPv6"></div></div><div class="section-header" style="margin-top:20px"><div><h2>配置替换规则</h2><p>重启前按原值查找并替换为新值</p></div><button class="button" id="rep-add" type="button">${icon('plus')}添加规则</button></div><div class="table-wrap"><table><thead><tr><th>原值（查找）</th><th>新值（替换）</th><th>备注</th><th>操作</th></tr></thead><tbody id="replacement-body">${replacements.length?replacements.map(replacementRow).join(''):replacementRow()}</tbody></table></div><div class="card-actions" style="margin-top:14px"><button class="button primary" id="override-save">保存覆盖配置并重启</button></div>`,{iconName:'settings',subtitle:'SOCKS5、ECS 和配置替换规则统一保存'})}
    <div style="height:16px"></div>
    ${card('配置管理',`<div class="grid grid-2"><div class="field"><label>MosDNS 本地工作目录</label><input id="config-workdir" value="${esc(storage.get('mosdnsConfigDir')||'')}" placeholder="例如 /etc/mosdns"></div><div class="field"><label>远程配置 ZIP 地址</label><input id="config-url" value="${esc(storage.get('mosdnsConfigUrl')||'')}" placeholder="https://github.com/.../archive/main.zip"></div></div><div class="card-actions" style="margin-top:14px"><button class="button" id="config-backup">${icon('download')}备份配置</button><button class="button primary" id="config-remote">应用远程配置</button></div><p class="form-note" style="margin-top:10px">远程更新会备份并覆盖现有配置，随后由后端重启 MosDNS。</p>`,{iconName:'settings'})}`;

    $('#audit-toggle').onclick=async()=>{await api.request(`/api/v1/audit/${status.capturing?'stop':'start'}`,{method:'POST'});toast('审计状态已更新');renderRoute(true)};
    $('#audit-clear').onclick=async()=>{if(!confirm('确定清空全部查询日志？'))return;await api.request('/api/v1/audit/clear',{method:'POST'});toast('查询日志已清空');renderRoute(true)};
    $('#cap-save').onclick=async()=>{await api.json('/api/v1/audit/capacity','POST',{capacity:+$('#audit-cap').value});toast('日志容量已保存')};
    $('#refresh-interval').onchange=()=>{CONFIG.refreshInterval=Math.max(5,+$('#refresh-interval').value||15);storage.set('mosdnsRefreshInterval',CONFIG.refreshInterval);toast('刷新间隔已更新')};
    const bindRepDelete=()=>$$('.rep-delete').forEach(x=>x.onclick=()=>{const rows=$$('.replacement-row');if(rows.length===1){$('.rep-original',x.closest('tr')).value='';$('.rep-new',x.closest('tr')).value='';$('.rep-comment',x.closest('tr')).value=''}else x.closest('tr').remove()});
    bindRepDelete();
    $('#rep-add').onclick=()=>{$('#replacement-body').insertAdjacentHTML('beforeend',replacementRow());bindRepDelete()};
    $('#override-save').onclick=async()=>{
      const replacements=$$('.replacement-row').map(r=>({original:$('.rep-original',r).value.trim(),new:$('.rep-new',r).value.trim(),comment:$('.rep-comment',r).value.trim()})).filter(r=>r.original);
      await api.json('/api/v1/overrides','POST',{socks5:$('#set-socks').value.trim(),ecs:$('#set-ecs').value.trim(),replacements});
      toast('覆盖配置已保存，正在重启');
      await api.json('/api/v1/system/restart','POST',{delay_ms:300});
    };
    $('#config-workdir').onchange=()=>storage.set('mosdnsConfigDir',$('#config-workdir').value.trim());
    $('#config-url').onchange=()=>storage.set('mosdnsConfigUrl',$('#config-url').value.trim());
    $('#config-backup').onclick=async()=>{
      const dir=$('#config-workdir').value.trim();
      if(!dir)throw new Error('请填写 MosDNS 本地工作目录');
      storage.set('mosdnsConfigDir',dir);
      const res=await fetch(api.url('/api/v1/config/export'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({dir})});
      if(!res.ok)throw new Error((await res.text())||`HTTP ${res.status}`);
      const blob=await res.blob();
      const disposition=res.headers.get('Content-Disposition')||'';
      const match=disposition.match(/filename[^;=]*=(?:\"([^\"]+)\"|([^;]+))/i);
      downloadBlob((match?.[1]||match?.[2]||'mosdns_backup.zip').trim(),blob);
      toast('配置备份下载已开始');
    };
    $('#config-remote').onclick=async()=>{
      const dir=$('#config-workdir').value.trim(),url=$('#config-url').value.trim();
      if(!dir||!url)throw new Error('请完整填写本地目录和远程配置地址');
      if(!confirm('远程配置会备份并覆盖现有设置，随后重启 MosDNS。确定继续？'))return;
      storage.set('mosdnsConfigDir',dir);storage.set('mosdnsConfigUrl',url);
      await api.json('/api/v1/config/update_from_url','POST',{dir,url});
      toast('远程配置任务已提交');
    };
  }

  const switchProfiles=[
    {tag:'switch1',name:'请求屏蔽',desc:'对无解析结果的请求进行屏蔽'}, {tag:'switch5',name:'类型屏蔽',desc:'屏蔽 SOA、PTR、HTTPS 等请求'},
    {tag:'switch4',name:'过期缓存 1',desc:'启用国内及国外缓存的过期响应'}, {tag:'switch13',name:'过期缓存 2',desc:'启用全部缓存并缓存 FakeIP'},
    {tag:'switch7',name:'广告屏蔽',desc:'启用 AdGuard 在线规则'}, {tag:'switch15',name:'极限加速',desc:'启用极限缓存与 UDP 加速'},
    {tag:'switch2',name:'指定 Client FakeIP',desc:'只允许指定客户端科学'}, {tag:'switch12',name:'指定 Client RealIP',desc:'指定客户端不允许科学'},
    {tag:'switch6',name:'IPv6 屏蔽',desc:'屏蔽 AAAA 请求类型'}
  ];
  async function renderFeatures(){const tags=['switch3',...switchProfiles.map(x=>x.tag)];const results=await Promise.all(tags.map(t=>safe(()=>api.request(`/plugins/${t}/show`),'error')));const status=Object.fromEntries(tags.map((t,i)=>[t,String(results[i]).trim()]));page.innerHTML=`${card('核心运行模式',`<div class="section-header"><div><h2>选择核心运行模式</h2><p>兼容模式性能更高；安全模式更注重防泄漏和劫持</p></div><div class="segmented"><button data-core="A" class="${status.switch3==='A'?'active':''}">兼容模式</button><button data-core="B" class="${status.switch3==='B'?'active':''}">安全模式</button></div></div>`,{iconName:'features'})}<div style="height:16px"></div>${card('功能开关',`<div class="feature-grid">${switchProfiles.map(p=>`<div class="feature-card"><div><h3>${esc(p.name)}</h3><p>${esc(p.desc)}</p></div><div class="feature-footer"><span class="badge ${status[p.tag]==='A'?'success':''}">${status[p.tag]==='A'?'已启用':'已关闭'}</span><label class="switch"><input data-switch="${p.tag}" type="checkbox" ${status[p.tag]==='A'?'checked':''} ${status[p.tag]==='error'?'disabled':''}><span class="switch-track"><span class="switch-thumb"></span></span></label></div></div>`).join('')}</div>`,{iconName:'features'})}`;$$('[data-core]').forEach(x=>x.onclick=async()=>{if(x.classList.contains('active'))return;await api.json('/plugins/switch3/post','POST',{value:x.dataset.core});toast('核心模式已切换，建议执行一次分流刷新');renderRoute(true)});$$('[data-switch]').forEach(x=>x.onchange=async()=>{try{await api.json(`/plugins/${x.dataset.switch}/post`,'POST',{value:x.checked?'A':'B'});toast('功能状态已保存')}catch(e){x.checked=!x.checked;toast('切换失败','error',e.message)}});}

  async function renderSystem(){const [metricsRaw,update]=await Promise.all([api.metrics(),safe(()=>api.request('/api/v1/update/status'),{})]);const sys=parseSystem(parseProm(metricsRaw));page.innerHTML=`<div class="grid grid-3">${card('系统信息',`<div class="kv-list"><div class="kv-row"><span class="kv-key">启动时间</span><span class="kv-value">${sys.start?new Date(sys.start*1000).toLocaleString('zh-CN'):'—'}</span></div><div class="kv-row"><span class="kv-key">运行时间</span><span class="kv-value">${duration(sys.uptime)}</span></div><div class="kv-row"><span class="kv-key">CPU 时间</span><span class="kv-value">${sys.cpu.toFixed(2)} 秒</span></div><div class="kv-row"><span class="kv-key">常驻内存</span><span class="kv-value">${fmtBytes(sys.rss)}</span></div><div class="kv-row"><span class="kv-key">空闲堆内存</span><span class="kv-value">${fmtBytes(sys.heapIdle)}</span></div><div class="kv-row"><span class="kv-key">Go 版本</span><span class="kv-value">${esc(sys.go)}</span></div><div class="kv-row"><span class="kv-key">线程 / Goroutine</span><span class="kv-value">${num(sys.threads)} / ${num(sys.goroutines)}</span></div><div class="kv-row"><span class="kv-key">文件描述符</span><span class="kv-value">${num(sys.fds)}</span></div></div>`,{iconName:'system'})}${card('版本与更新',`<div class="kv-list"><div class="kv-row"><span class="kv-key">当前版本</span><span class="kv-value" title="${esc(update.current_version||'—')}">MosDNS V5.5</span></div><div class="kv-row"><span class="kv-key">最新版本</span><span class="kv-value" title="${esc(update.latest_version||'—')}">MosDNS V5.5</span></div><div class="kv-row"><span class="kv-key">架构</span><span class="kv-value">${esc(update.architecture||'—')}</span></div><div class="kv-row"><span class="kv-key">上次检查</span><span class="kv-value">${fmtDate(update.checked_at)}</span></div><div class="kv-row"><span class="kv-key">状态</span><span class="kv-value">${esc(update.message|| (update.update_available?'可更新':'已是最新'))}</span></div></div><div class="card-actions" style="margin-top:14px"><button class="button" id="update-check">强制检查</button><button class="button primary" id="update-apply" ${update.update_available?'':'disabled'}>立即更新</button></div>`,{iconName:'refresh'})}${card('服务控制',`<div class="empty-state" style="min-height:220px"><div><div class="empty-icon">${icon('system')}</div><strong>MosDNS 服务</strong><p>重启前请确认配置已经保存。</p><button class="button danger" id="system-restart">重启 MosDNS</button></div></div>`,{iconName:'settings'})}</div>`;$('#update-check').onclick=async()=>{await api.request('/api/v1/update/check',{method:'POST'});toast('版本检查完成');renderRoute(true)};$('#update-apply').onclick=async()=>{if(!confirm('确定更新 MosDNS？'))return;await api.json('/api/v1/update/apply','POST',{force:false,prefer_v3:false});toast('更新任务已提交')};$('#system-restart').onclick=restartService;}

  async function restartService(){if(!confirm('确定重启 MosDNS？短时间内 DNS 服务会中断。'))return;await api.json('/api/v1/system/restart','POST',{delay_ms:500});toast('MosDNS 正在重启');setTimeout(()=>renderRoute(true),4000);}
  async function openAuditModal(){const [s,c]=await Promise.all([api.status(),api.capacity()]);modalOpen('审计控制','控制 DNS 查询日志的记录状态',`<div class="kv-list"><div class="kv-row"><span class="kv-key">当前状态</span><span class="kv-value">${s.capturing?'运行中':'已停止'}</span></div><div class="kv-row"><span class="kv-key">容量</span><span class="kv-value">${num(c.capacity)} 条</span></div></div><div class="grid grid-2" style="margin-top:16px"><button class="button ${s.capturing?'danger':'success'}" id="modal-audit-toggle">${s.capturing?'关闭审计':'开启审计'}</button><button class="button danger" id="modal-audit-clear">清空日志</button></div>`,null,false);$('#modal-audit-toggle').onclick=async()=>{await api.request(`/api/v1/audit/${s.capturing?'stop':'start'}`,{method:'POST'});toast('审计状态已更新');modalClose();renderRoute(true)};$('#modal-audit-clear').onclick=async()=>{if(!confirm('确定清空日志？'))return;await api.request('/api/v1/audit/clear',{method:'POST'});toast('日志已清空');modalClose();renderRoute(true)}}
  async function loadAliases(){try{state.aliases=await api.request('/plugins/clientname')||{}}catch{state.aliases={}}}
  async function openAliasModal(){await loadAliases();const clients=await api.rank('client',200);modalOpen('客户端别名','别名保存在 MosDNS 的 webinfo/clientname.json',`<div class="stack" id="alias-list">${clients.length?clients.map(x=>`<div class="grid grid-2"><div class="field"><label>客户端 IP</label><input value="${esc(x.key)}" disabled></div><div class="field"><label>别名</label><input data-alias-ip="${esc(x.key)}" value="${esc(state.aliases[x.key]||'')}"></div></div>`).join(''):empty('日志中暂无客户端')}</div>`,async()=>{const next={...state.aliases};$$('[data-alias-ip]').forEach(x=>{const v=x.value.trim();if(v)next[x.dataset.aliasIp]=v;else delete next[x.dataset.aliasIp]});await api.json('/plugins/clientname','PUT',next);state.aliases=next;toast('客户端别名已保存');renderRoute(true)});}

  function openDrawer(title,subtitle,html){if(title!=='设备流量详情')state.trafficDetailIP=null;$('#drawer-title').textContent=title;$('#drawer-subtitle').textContent=subtitle;$('#drawer-content').innerHTML=html;$('#drawer').classList.add('open');$('#drawer').setAttribute('aria-hidden','false');$('#drawer-backdrop').classList.add('open')}
  function closeDrawer(){state.trafficDetailIP=null;$('#drawer').classList.remove('open');$('#drawer').setAttribute('aria-hidden','true');$('#drawer-backdrop').classList.remove('open')}
  function modalOpen(title,subtitle,html,onSave,showActions=true){$('#modal-title').textContent=title;$('#modal-subtitle').textContent=subtitle||'';$('#modal-content').innerHTML=html;$('#modal-actions').innerHTML=showActions?`<button class="button" value="cancel">取消</button><button class="button primary" id="modal-save" type="button">保存</button>`:'';const d=$('#modal');d.showModal();if(onSave&&showActions)$('#modal-save').onclick=async()=>{const b=$('#modal-save');b.disabled=true;try{await onSave();modalClose()}catch(e){toast('操作失败','error',e.message)}finally{b.disabled=false}};}
  function modalClose(){const d=$('#modal');if(d.open)d.close()}
  function downloadBlob(name,blob){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},100)}
  function downloadText(name,text){downloadBlob(name,new Blob([text],{type:'text/plain;charset=utf-8'}))}
  async function safe(fn,fallback){try{return await fn()}catch{return fallback}}

  initShell(); CONFIG.refreshInterval=+(storage.get('mosdnsRefreshInterval')||CONFIG.refreshInterval||15); loadAliases().catch(()=>{}); navigate(location.hash.replace(/^#\/?/,'')||'overview',false);
})();
